"""
The abstract boundary between "application logic" and "LLM interaction".

Everything above this interface (conversation_engine.py, main.py) only ever
talks to LLMProvider.take_turn(). It never knows or cares whether the
underlying implementation is a deterministic mock, an Anthropic API call, or
something else entirely. This is what lets the app run with zero credentials
(MockProvider) and swap in a real model by changing one env var.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List

from app.schemas import ChatMessage, LLMTurnResponse, WishesState


class LLMError(Exception):
    """Raised when a provider cannot produce a usable response at all
    (network failure, missing credentials, or output that fails validation
    even after a retry). Callers must handle this gracefully."""


class LLMProvider(ABC):
    @abstractmethod
    def take_turn(
        self,
        state: WishesState,
        history: List[ChatMessage],
        user_message: str,
    ) -> LLMTurnResponse:
        """
        Given the current structured state, the conversation so far, and the
        newest user message, return a validated LLMTurnResponse.

        Implementations are responsible for their own retry policy on
        malformed output, but must raise LLMError rather than returning a
        best-effort guess if they cannot produce something that validates.
        """
        raise NotImplementedError
