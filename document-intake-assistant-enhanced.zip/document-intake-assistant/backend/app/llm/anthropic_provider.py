"""
Real LLM provider backed by the Anthropic Messages API.

Swapping the mock for this is a one-line config change (LLM_PROVIDER=anthropic
in .env, plus ANTHROPIC_API_KEY) — see app/conversation_engine.py::get_provider.
Everything else in the application (state management, validation, document
generation, the frontend) is completely unaware of which provider is active.
"""
from __future__ import annotations

import json
from typing import List

from pydantic import ValidationError

from app.config import settings
from app.llm.base import LLMError, LLMProvider
from app.schemas import ChatMessage, FIELD_REGISTRY, LLMTurnResponse, WishesState

SYSTEM_PROMPT_TEMPLATE = """You are the extraction engine behind a conversational intake form \
for a FICTIONAL "Personal Wishes Document" (not a real legal will; this is a demo product).

Your ONLY job each turn is to:
1. Read the latest user message (and the recent conversation for context).
2. Extract values for any of the known fields that the user has clearly and explicitly stated.
3. Flag fields as ambiguous if the user's answer is unclear, contradictory, or uncertain -
   do NOT guess or invent a value in that case.
4. Write a short, warm, natural next message: either a clarifying question for an ambiguous
   field, or the next unanswered question from the field list, or an acknowledgement if the
   interview is complete.

Known fields (only use these exact names):
{field_list}

Rules:
- NEVER invent or assume a value that was not explicitly stated.
- Only ever ask about ONE thing at a time in assistant_reply.
- Do not re-ask about fields that are already confirmed in the current state, unless the
  user's message is clearly a correction to that field.
- If the user gives several fields in one message, extract all of them.
- Respond with ONLY valid JSON matching this exact schema, nothing else - no markdown fences,
  no commentary:

{{
  "extracted_updates": [{{"field": "<field_name>", "value": <value>}}],
  "ambiguous_fields": [{{"field": "<field_name>", "reason": "<short reason>"}}],
  "assistant_reply": "<your next message to the user>"
}}
"""


def _build_system_prompt() -> str:
    lines = []
    for f in FIELD_REGISTRY:
        lines.append(f"- {f.name} ({f.type}): {f.question}")
    return SYSTEM_PROMPT_TEMPLATE.format(field_list="\n".join(lines))


class AnthropicProvider(LLMProvider):
    def __init__(self):
        if not settings.ANTHROPIC_API_KEY:
            raise LLMError(
                "ANTHROPIC_API_KEY is not configured. Set LLM_PROVIDER=mock to run without "
                "a real API key, or set ANTHROPIC_API_KEY in your .env file."
            )
        try:
            import anthropic  # imported lazily so the mock path never needs the package
        except ImportError as e:
            raise LLMError(
                "The 'anthropic' package is not installed. Run: pip install anthropic"
            ) from e
        self._client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
        self._system_prompt = _build_system_prompt()

    def take_turn(
        self,
        state: WishesState,
        history: List[ChatMessage],
        user_message: str,
    ) -> LLMTurnResponse:
        state_summary = state.model_dump(exclude={"pending_reasons"})
        history_text = "\n".join(f"{m.role}: {m.content}" for m in history[-10:])

        user_prompt = (
            f"Current structured state:\n{json.dumps(state_summary, default=str)}\n\n"
            f"Recent conversation:\n{history_text}\n\n"
            f"Latest user message: {user_message}\n\n"
            "Respond with ONLY the JSON object described in the system prompt."
        )

        last_error = None
        for attempt in range(2):  # one retry on malformed output
            try:
                resp = self._client.messages.create(
                    model=settings.ANTHROPIC_MODEL,
                    max_tokens=1000,
                    system=self._system_prompt + (
                        "" if attempt == 0 else
                        f"\n\nYour previous response was invalid JSON or failed schema "
                        f"validation ({last_error}). Return ONLY valid JSON this time."
                    ),
                    messages=[{"role": "user", "content": user_prompt}],
                )
                raw_text = "".join(
                    block.text for block in resp.content if getattr(block, "type", "") == "text"
                )
                cleaned = raw_text.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
                parsed = json.loads(cleaned)
                return LLMTurnResponse.model_validate(parsed)
            except (json.JSONDecodeError, ValidationError) as e:
                last_error = str(e)
                continue
            except Exception as e:  # network / API errors - no point retrying immediately
                raise LLMError(f"Anthropic API call failed: {e}") from e

        raise LLMError(
            f"Model returned invalid output twice in a row; giving up. Last error: {last_error}"
        )
