"""
A deterministic, rule-based stand-in for a real LLM.

This exists so the whole application works with zero API keys (per the
brief: "Access to a paid LLM API is not required"). It implements the exact
same LLMProvider interface and returns the exact same LLMTurnResponse
contract that a real model would, so swapping in AnthropicProvider later is
a one-line change (see app/conversation_engine.py::get_provider).

Design: rather than one big regex soup, each field has its own small
extractor. The provider scans the user's message against every field's
extractor (so multi-field, out-of-order, and correction messages are all
handled), then additionally treats the message as a plausible answer to
whichever field the interview would ask next, if nothing else matched.
"""
from __future__ import annotations

import re
from typing import List, Optional, Tuple

from app.llm.base import LLMProvider
from app.schemas import (
    ChatMessage,
    FIELD_REGISTRY,
    LLMAmbiguity,
    LLMFieldUpdate,
    LLMTurnResponse,
    WishesState,
    FieldStatus,
)

UNCERTAIN_MARKERS = ("not sure", "don't know", "dont know", "no idea", "maybe", "i think",
                     "possibly", "unsure")

GREETING_WORDS = {
    "hi", "hello", "hey", "hiya", "howdy", "good morning", "good evening",
    "good afternoon", "greetings", "sup", "yo", "hola",
}

CHITCHAT_WORDS = {
    "thanks", "thank you", "thx", "appreciate it", "great", "awesome",
    "cool", "perfect", "got it", "understood", "all good", "sounds good",
    "okay", "ok", "fine", "done", "bye", "goodbye", "cheers",
}

HELP_WORDS = {
    "help", "what is this", "what can you do", "who are you", "what are you",
    "how does this work", "instructions", "commands", "what do i do", "options",
}

YES_WORDS = {
    "yes", "y", "yeah", "yep", "correct", "true", "worldwide", "worldwide assets",
    "all countries", "everywhere", "sure", "affirmative", "global", "all assets",
    "international", "cover all", "both uk and abroad", "every country",
}
NO_WORDS = {
    "no", "n", "nope", "false", "just uk", "uk only", "only uk", "one country",
    "single country", "single country (uk only)", "only one country",
    "only assets in one country", "not worldwide", "negative", "single",
    "just the uk", "in the uk", "only in the uk", "local only", "england only",
    "britain only", "united kingdom only",
}
NONE_WORDS = {
    "no", "none", "n/a", "na", "nothing", "not applicable", "nope",
    "no that's everything", "no thats everything", "that's all", "thats all",
    "nothing else", "no that is all", "no that's all", "no gifts", "no wishes",
    "no specific gifts", "no additional wishes", "none at all", "nil", "zero",
}

NONE_PHRASES_RE = re.compile(
    r"\b(that'?s (all|everything)|nothing else|no more|no (other|additional|specific) (wishes|gifts)?|don'?t have any|do not have any)\b",
    re.IGNORECASE,
)


def _is_uncertain(text: str) -> bool:
    t = text.lower()
    return any(m in t for m in UNCERTAIN_MARKERS)


def _is_pure_greeting(text: str) -> bool:
    t = text.lower().strip().strip("!.,? ")
    return t in GREETING_WORDS


def _is_pure_help(text: str) -> bool:
    t = text.lower().strip().strip("!.,? ")
    return t in HELP_WORDS or any(p in t for p in ("help me", "how to use", "what to do", "what do i"))


def _is_pure_chitchat(text: str) -> bool:
    t = text.lower().strip().strip("!.,? ")
    return t in CHITCHAT_WORDS


def _parse_yes_no(text: str) -> Optional[bool]:
    t = text.lower().strip().strip(".")
    if _is_uncertain(t):
        return None
    for w in NO_WORDS:
        if re.search(rf"\b{re.escape(w)}\b", t):
            return False
    for w in YES_WORDS:
        if re.search(rf"\b{re.escape(w)}\b", t):
            return True
    return None


_NAME_PREFIXES = re.compile(
    r"^(my name is|my full name is|i am|i'm|im|it'?s|name[:\-]?\s*|change (?:my )?name to|update (?:my )?name to)\s*",
    re.IGNORECASE,
)


def _clean_name(text: str) -> str:
    t = text.strip().strip(".")
    t = _NAME_PREFIXES.sub("", t).strip()
    low = t.lower()
    # Reject greetings or words that cannot be a person's name
    if low in GREETING_WORDS or low in CHITCHAT_WORDS or low in HELP_WORDS or low in ("yes", "no", "none"):
        return ""
    return t


_ADDRESS_PREFIXES = re.compile(
    r"^(my address is|my home address is|i live at|address[:\-]?\s*|it'?s|change (?:my )?address to|update (?:my )?address to)\s*",
    re.IGNORECASE,
)


def _clean_address(text: str) -> str:
    t = text.strip().strip(".")
    t = _ADDRESS_PREFIXES.sub("", t).strip()
    return t


_RELATIONSHIP_WORDS = [
    "brother", "sister", "sibling", "mother", "mom", "father", "dad", "son", "daughter",
    "wife", "husband", "spouse", "partner", "friend", "close friend", "best friend",
    "cousin", "aunt", "uncle", "nephew", "niece", "solicitor", "lawyer", "colleague",
    "daughter-in-law", "son-in-law", "brother-in-law", "sister-in-law",
]

_RELATIONSHIP_PREFIXES = re.compile(
    r"^(he is my|she is my|they are my|is my|my|they're my|it'?s my|they are|he is|she is)\s+",
    re.IGNORECASE,
)


def _clean_relationship(text: str) -> str:
    t = text.strip().strip(".")
    t = _RELATIONSHIP_PREFIXES.sub("", t).strip()
    return t


# Keyword anchors for full_name / home_address, so a combined answer like
# "My name is Jane Smith and I live at 12 Elm Street" extracts BOTH fields
# in one turn, in any order, rather than only ever filling whichever field
# happens to be "expected next".
_NAME_ANCHOR = re.compile(
    r"(?:my (?:full )?name is|name is|name's|change (?:my )?name to|update (?:my )?name to|name[:\-]\s*)\s+"
    r"((?:(?:dr|mr|mrs|ms|prof)\.?\s+)?[A-Za-z\'-]+(?:\s+[A-Za-z\'-]+)*?)(?=(?:\s+and\s+(?:i|my)\b)|[.,;\n]|$)",
    re.IGNORECASE,
)
_ADDRESS_ANCHOR = re.compile(
    r"(?:i live at|my address is|home address is|address is|change (?:my )?address to|update (?:my )?address to|address[:\-]\s*)\s+"
    r"(.+?)(?=(?:\s+and\s+(?:my|i\b))|$)",
    re.IGNORECASE,
)


_EXECUTOR_PREFIXES = re.compile(
    r"^(?:change (?:my )?executor to|update (?:my )?executor to|my executor (?:is|should be|to be)|appoint|make|executor[:\-]?\s*)\s*",
    re.IGNORECASE,
)


def _extract_executor(text: str) -> Tuple[Optional[str], Optional[str]]:
    """Returns (name, relationship) from phrasing like 'my brother James',
    'James, my brother', 'James is my brother', 'appoint James, my brother',
    or 'change executor to Kyle Reese, partner'."""
    t = text.strip().strip(".")
    has_exec_prefix = bool(_EXECUTOR_PREFIXES.search(t))
    cleaned = _EXECUTOR_PREFIXES.sub("", t).strip()
    low = cleaned.lower()

    found_rel = None
    for rel in _RELATIONSHIP_WORDS:
        if re.search(rf"\b{re.escape(rel)}\b", low):
            found_rel = rel
            break

    if found_rel:
        # Pattern 1: '[my] <rel> <Name>' e.g. 'My brother James'
        m = re.search(rf"\b(?:my\s+)?{re.escape(found_rel)}\s+([A-Za-z\'-]+(?:\s+[A-Za-z\'-]+)*)", cleaned, re.IGNORECASE)
        if m:
            return m.group(1).strip().rstrip("."), found_rel

        # Pattern 2: '<Name>, [my] <rel>' or '<Name> is [my] <rel>' e.g. 'James, my brother' or 'James is my brother'
        m = re.search(rf"^(.+?)(?:[,\s]+(?:(?:who\s+)?is\s+)?(?:my\s+)?)\b{re.escape(found_rel)}\b", cleaned, re.IGNORECASE)
        if m:
            c = _clean_name(m.group(1))
            if c and len(c) >= 2:
                return c, found_rel

        return None, found_rel

    if has_exec_prefix or "executor" in t.lower() or "appoint" in t.lower():
        cleaned_name = _clean_name(cleaned)
        if cleaned_name and len(cleaned_name) >= 2:
            return cleaned_name, None

    return None, None


def _split_list(text: str) -> List[str]:
    t = text.strip().strip(".")
    # Clean leading "my children are", "just", etc.
    t = re.sub(r"^(?:my (?:children|kids) are|just|only|my children|my kids)\s*", "", t, flags=re.IGNORECASE)
    parts = re.split(r",| and | & ", t)
    return [p.strip() for p in parts if p.strip()]


def _is_none_answer(text: str) -> bool:
    t = text.lower().strip().strip(".")
    if t in NONE_WORDS:
        return True
    if NONE_PHRASES_RE.search(t):
        if "but" in t or "except" in t or "actually" in t:
            return False
        return True
    return False


def _next_expected_field(state: WishesState) -> Optional[str]:
    for f in FIELD_REGISTRY:
        if f.depends_on and getattr(state, f.depends_on, None) is not f.depends_value:
            continue
        if state.status.get(f.name) in (FieldStatus.MISSING, FieldStatus.PENDING):
            return f.name
    return None


class MockLLMProvider(LLMProvider):
    """Deterministic, offline stand-in for a real LLM. See module docstring."""

    def take_turn(
        self,
        state: WishesState,
        history: List[ChatMessage],
        user_message: str,
    ) -> LLMTurnResponse:
        updates: List[LLMFieldUpdate] = []
        ambiguous: List[LLMAmbiguity] = []
        matched_fields: set[str] = set()

        target = _next_expected_field(state)
        low = user_message.lower().strip()

        # --- Priority 1: Handle Pure Help Queries -------------------------
        if _is_pure_help(user_message):
            if target is None:
                reply = (
                    "I am your Document Intake Assistant. Your draft Personal Wishes Document "
                    "is complete! You can review the draft on the right, download it as Markdown or JSON, "
                    "print or save it as PDF, or ask me to change any detail (e.g. 'update executor to Alice')."
                )
            else:
                reply = (
                    "I am your Document Intake Assistant. I help you draft a Personal Wishes Document "
                    f"through a quick step-by-step interview. Right now, I need: {FIELD_BY_NAME[target].question}"
                )
            return LLMTurnResponse(
                extracted_updates=[],
                ambiguous_fields=[],
                assistant_reply=reply,
            )

        # --- Priority 2: Handle Pure Greetings ----------------------------
        if _is_pure_greeting(user_message):
            if target is None:
                reply = (
                    "Hello! Your draft Personal Wishes Document is already complete and ready for review. "
                    "You can inspect the structured data on the right, export it (Markdown, JSON, or Print/PDF), "
                    "or let me know if you would like to update any answer (for example, 'change my executor to John Smith')."
                )
            elif target == "full_name":
                reply = (
                    "Hello! I'm here to help you draft your Personal Wishes Document. "
                    "To get started, what is your full legal name?"
                )
            else:
                reply = f"Hello! Let's continue with your draft. {FIELD_BY_NAME[target].question}"
            return LLMTurnResponse(
                extracted_updates=[],
                ambiguous_fields=[],
                assistant_reply=reply,
            )

        # --- Priority 3: Handle Pure Acknowledgements / Pleasantries ------
        if _is_pure_chitchat(user_message):
            if target is None:
                reply = (
                    "You're very welcome! Your draft document is ready. You can review the audit trail, "
                    "download Markdown or JSON, or print the document using the buttons above."
                )
                return LLMTurnResponse(extracted_updates=[], ambiguous_fields=[], assistant_reply=reply)
            elif target != "covers_worldwide_assets" and target != "has_children":
                # For string/list questions, "thanks" or "okay" isn't a valid answer
                reply = f"Glad to help! Let's continue: {FIELD_BY_NAME[target].question}"
                return LLMTurnResponse(extracted_updates=[], ambiguous_fields=[], assistant_reply=reply)

        # --- Opportunistic, keyword-anchored extraction (handles corrections
        # and out-of-order / multi-field answers, regardless of what was
        # "expected" next) -------------------------------------------------
        name_m = _NAME_ANCHOR.search(user_message)
        if name_m:
            c_name = _clean_name(name_m.group(1))
            if c_name:
                updates.append(LLMFieldUpdate(field="full_name", value=c_name))
                matched_fields.add("full_name")

        addr_m = _ADDRESS_ANCHOR.search(user_message)
        if addr_m:
            addr_val = _clean_address(addr_m.group(1)).strip().rstrip(".")
            if addr_val:
                updates.append(LLMFieldUpdate(field="home_address", value=addr_val))
                matched_fields.add("home_address")

        if any(w in low for w in ("worldwide", "assets", "single country", "uk only", "only uk", "just uk", "global assets", "all countries", "one country")):
            val = _parse_yes_no(user_message)
            if val is None:
                ambiguous.append(LLMAmbiguity(
                    field="covers_worldwide_assets",
                    reason="Could not tell if this means worldwide or single-country coverage.",
                ))
            else:
                updates.append(LLMFieldUpdate(field="covers_worldwide_assets", value=val))
            matched_fields.add("covers_worldwide_assets")

        if any(w in low for w in ("child", "children", "kids", "son", "daughter")):
            val = _parse_yes_no(user_message)
            if val is None and not _is_uncertain(user_message):
                if re.search(r"\b(have|has|got|one|two|three|\d+)\b", low) and "no " not in low and "don't" not in low:
                    val = True
            if val is None:
                ambiguous.append(LLMAmbiguity(
                    field="has_children",
                    reason="Could not tell whether the user has children.",
                ))
            else:
                updates.append(LLMFieldUpdate(field="has_children", value=val))
                # Check if names were also mentioned, e.g. "I have two children: Alice and Bob"
                if val is True:
                    kids_m = re.search(r"(?:named|names are|called|children are|kids are|children:)\s*(.+)", user_message, re.IGNORECASE)
                    if kids_m:
                        c_names = _split_list(kids_m.group(1))
                        if c_names:
                            updates.append(LLMFieldUpdate(field="children_names", value=c_names))
                            matched_fields.add("children_names")
            matched_fields.add("has_children")

        exec_name, exec_rel = _extract_executor(user_message)
        if exec_name or exec_rel:
            if exec_name and exec_rel:
                updates.append(LLMFieldUpdate(field="executor_name", value=exec_name))
                updates.append(LLMFieldUpdate(field="executor_relationship", value=exec_rel))
                matched_fields.add("executor_name")
                matched_fields.add("executor_relationship")
            elif exec_name:
                updates.append(LLMFieldUpdate(field="executor_name", value=exec_name))
                matched_fields.add("executor_name")
            elif exec_rel:
                if target == "executor_relationship" or state.status.get("executor_name") == FieldStatus.CONFIRMED:
                    updates.append(LLMFieldUpdate(field="executor_relationship", value=exec_rel))
                    matched_fields.add("executor_relationship")
                else:
                    updates.append(LLMFieldUpdate(field="executor_relationship", value=exec_rel))
                    ambiguous.append(LLMAmbiguity(
                        field="executor_name",
                        reason="A relationship was mentioned but no clear name was found.",
                    ))
                    matched_fields.add("executor_name")
                    matched_fields.add("executor_relationship")

        # Specific gifts opportunistic check
        if any(w in low for w in ("gift", "bequest", "leave my", "give my")):
            if _is_none_answer(user_message):
                updates.append(LLMFieldUpdate(field="specific_gifts", value=[]))
                matched_fields.add("specific_gifts")
            else:
                clean_gifts = re.sub(r"^(?:my specific gifts are|specific gifts:|gifts?:)\s*", "", user_message, flags=re.IGNORECASE)
                gift_items = _split_list(clean_gifts)
                if gift_items:
                    updates.append(LLMFieldUpdate(field="specific_gifts", value=gift_items))
                    matched_fields.add("specific_gifts")

        # Additional wishes opportunistic check
        if any(w in low for w in ("funeral", "cremation", "burial", "additional wish", "extra wish")):
            if _is_none_answer(user_message):
                updates.append(LLMFieldUpdate(field="additional_wishes", value=None))
                matched_fields.add("additional_wishes")
            else:
                clean_wishes = re.sub(r"^(?:my additional wishes are|additional wishes?:|wishes?:)\s*", "", user_message, flags=re.IGNORECASE)
                updates.append(LLMFieldUpdate(field="additional_wishes", value=clean_wishes.strip()))
                matched_fields.add("additional_wishes")

        # --- Fall back: treat the raw message as the answer to whatever
        # field the interview is currently waiting on -----------------------
        if target and target not in matched_fields:
            field_def = next(f for f in FIELD_REGISTRY if f.name == target)

            if _is_uncertain(user_message):
                ambiguous.append(LLMAmbiguity(
                    field=target,
                    reason="The user expressed uncertainty; needs a follow-up.",
                ))
            elif field_def.type == "bool":
                val = _parse_yes_no(user_message)
                if val is None:
                    ambiguous.append(LLMAmbiguity(
                        field=target,
                        reason="Could not parse a clear yes/no answer.",
                    ))
                else:
                    updates.append(LLMFieldUpdate(field=target, value=val))
            elif field_def.type == "list[str]":
                if _is_none_answer(user_message):
                    updates.append(LLMFieldUpdate(field=target, value=[]))
                else:
                    updates.append(LLMFieldUpdate(field=target, value=_split_list(user_message)))
            else:  # str
                if not field_def.required and _is_none_answer(user_message):
                    updates.append(LLMFieldUpdate(field=target, value=None))
                elif target == "full_name":
                    c_name = _clean_name(user_message)
                    if c_name and len(c_name) >= 2:
                        updates.append(LLMFieldUpdate(field=target, value=c_name))
                    else:
                        ambiguous.append(LLMAmbiguity(
                            field=target,
                            reason="Please provide your full legal name.",
                        ))
                elif target == "home_address":
                    c_addr = _clean_address(user_message)
                    if c_addr and len(c_addr) >= 3:
                        updates.append(LLMFieldUpdate(field=target, value=c_addr))
                    else:
                        ambiguous.append(LLMAmbiguity(
                            field=target,
                            reason="Please provide your full home address.",
                        ))
                elif target == "executor_name":
                    c_exec = _clean_name(user_message)
                    if c_exec and len(c_exec) >= 2:
                        updates.append(LLMFieldUpdate(field=target, value=c_exec))
                    else:
                        ambiguous.append(LLMAmbiguity(
                            field=target,
                            reason="Please provide the full name of your executor.",
                        ))
                elif target == "executor_relationship":
                    updates.append(LLMFieldUpdate(field=target, value=_clean_relationship(user_message)))
                else:
                    cleaned = user_message.strip()
                    if len(cleaned) < 1:
                        ambiguous.append(LLMAmbiguity(
                            field=target, reason="Empty or unreadable response.",
                        ))
                    else:
                        updates.append(LLMFieldUpdate(field=target, value=cleaned))

        assistant_reply = self._compose_reply(state, updates, ambiguous, target=target)
        return LLMTurnResponse(
            extracted_updates=updates,
            ambiguous_fields=ambiguous,
            assistant_reply=assistant_reply,
        )

    @staticmethod
    def _compose_reply(
        state: WishesState,
        updates: List[LLMFieldUpdate],
        ambiguous: List[LLMAmbiguity],
        target: Optional[str] = None,
    ) -> str:
        if ambiguous:
            a = ambiguous[0]
            field_def = next(f for f in FIELD_REGISTRY if f.name == a.field)
            return f"Sorry, I didn't quite catch that. {field_def.question}"
        if updates:
            fields_updated = [u.field.replace("_", " ") for u in updates]
            if len(fields_updated) == 1:
                return f"Got it, recorded {fields_updated[0]}."
            return f"Got it, recorded {', '.join(fields_updated)}."
        if target is None:
            return (
                "Your draft Personal Wishes Document is complete. You can download or print your document "
                "using the buttons above, or let me know if you would like to modify any detail (e.g. 'update address to...')."
            )
        return "Could you tell me a bit more?"
