"""
Real LLM provider backed by OpenAI Chat Completions API (GPT-4o, GPT-4o-mini, etc.).
Uses httpx directly to avoid requiring extra heavy client libraries.
"""
from __future__ import annotations

import json
from typing import List

from pydantic import ValidationError
import httpx

from app.config import settings
from app.llm.base import LLMError, LLMProvider
from app.schemas import ChatMessage, FIELD_REGISTRY, LLMTurnResponse, WishesState

SYSTEM_PROMPT_TEMPLATE = """You are the extraction engine behind a conversational intake form \
for a FICTIONAL "Personal Wishes Document" (not a real legal will; this is a demo product).

Your ONLY job each turn is to:
1. Read the latest user message (and the recent conversation for context).
2. Extract values for any of the known fields that the user has clearly and explicitly stated.
3. Flag fields as ambiguous if the user's answer is unclear, contradictory, or uncertain -
   do NOT guess or invent a value in that case.
4. Write a short, warm, natural next message: either a clarifying question for an ambiguous
   field, or the next unanswered question from the field list, or an acknowledgement if the
   interview is complete.

Known fields (only use these exact names):
{field_list}

Rules:
- NEVER invent or assume a value that was not explicitly stated.
- Only ever ask about ONE thing at a time in assistant_reply.
- Do not re-ask about fields that are already confirmed in the current state, unless the
  user's message is clearly a correction to that field.
- If the user gives several fields in one message, extract all of them.
- Respond with ONLY valid JSON matching this exact schema:

{{
  "extracted_updates": [{{"field": "<field_name>", "value": <value>}}],
  "ambiguous_fields": [{{"field": "<field_name>", "reason": "<short reason>"}}],
  "assistant_reply": "<your next message to the user>"
}}
"""


def _build_system_prompt() -> str:
    lines = []
    for f in FIELD_REGISTRY:
        lines.append(f"- {f.name} ({f.type}): {f.question}")
    return SYSTEM_PROMPT_TEMPLATE.format(field_list="\n".join(lines))


class OpenAIProvider(LLMProvider):
    def __init__(self):
        if not settings.OPENAI_API_KEY:
            raise LLMError(
                "OPENAI_API_KEY is not configured. Set LLM_PROVIDER=mock to run without "
                "a real API key, or set OPENAI_API_KEY in your .env file."
            )
        self.api_key = settings.OPENAI_API_KEY
        self.model = settings.OPENAI_MODEL
        self._system_prompt = _build_system_prompt()

    def take_turn(
        self,
        state: WishesState,
        history: List[ChatMessage],
        user_message: str,
    ) -> LLMTurnResponse:
        state_summary = state.model_dump(exclude={"pending_reasons", "contradictions", "audit_trail"})
        history_text = "\n".join(f"{m.role}: {m.content}" for m in history[-10:])

        user_prompt = (
            f"Current structured state:\n{json.dumps(state_summary, default=str)}\n\n"
            f"Recent conversation:\n{history_text}\n\n"
            f"Latest user message: {user_message}\n\n"
            "Respond with ONLY the JSON object described in the system prompt."
        )

        messages = [
            {"role": "system", "content": self._system_prompt},
            {"role": "user", "content": user_prompt},
        ]

        last_error = None
        for attempt in range(2):
            try:
                resp = httpx.post(
                    "https://api.openai.com/v1/chat/completions",
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "model": self.model,
                        "messages": messages,
                        "response_format": {"type": "json_object"},
                        "temperature": 0.2,
                    },
                    timeout=25.0,
                )
                if resp.status_code != 200:
                    raise LLMError(f"OpenAI API error ({resp.status_code}): {resp.text}")

                data = resp.json()
                raw_text = data["choices"][0]["message"]["content"]
                parsed = json.loads(raw_text)
                return LLMTurnResponse.model_validate(parsed)
            except (json.JSONDecodeError, ValidationError) as e:
                last_error = str(e)
                messages.append({"role": "user", "content": f"Your previous response failed validation: {last_error}. Return valid JSON."})
                continue
            except LLMError:
                raise
            except Exception as e:
                raise LLMError(f"OpenAI network/API call failed: {e}") from e

        raise LLMError(f"OpenAI returned invalid output twice: {last_error}")
