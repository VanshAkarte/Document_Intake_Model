"""
Orchestrates one conversational turn.

Seam between untrusted LLM interaction, validation, contradiction detection,
and deterministic state transitions.

Guarantees:
1. Untrusted LLM output is parsed against strict Pydantic schemas.
2. Field values are coerced and validated field-by-field.
3. Contradictions with previously confirmed facts are caught and resolved.
4. The application deterministically re-derives the next required question.
5. All actions are immutably logged to the state's audit trail.
"""
from __future__ import annotations

from typing import Dict, List, Optional

from app.config import settings
from app.contradiction_detector import detect_contradictions
from app.document_generator import generate_document
from app.llm.anthropic_provider import AnthropicProvider
from app.llm.base import LLMError, LLMProvider
from app.llm.gemini_provider import GeminiProvider
from app.llm.mock_provider import MockLLMProvider
from app.llm.openai_provider import OpenAIProvider
from app.schemas import ChatMessage, FIELD_BY_NAME, FIELD_REGISTRY, TurnResult, WishesState
from app.state_manager import (
    apply_updates,
    is_interview_complete,
    mark_contradictory,
    mark_pending,
    next_expected_field,
)
from app.validation import validate_updates

_providers: Dict[str, LLMProvider] = {}


def get_provider(provider_name: Optional[str] = None) -> LLMProvider:
    """Returns or instantiates the requested LLM provider."""
    name = (provider_name or settings.LLM_PROVIDER or "mock").lower()
    if name in _providers:
        return _providers[name]

    if name == "anthropic":
        p = AnthropicProvider()
    elif name == "openai":
        p = OpenAIProvider()
    elif name == "gemini":
        p = GeminiProvider()
    else:
        p = MockLLMProvider()

    _providers[name] = p
    return p


def get_available_providers() -> List[Dict[str, str]]:
    """Returns a list of supported providers with configured status."""
    return [
        {"id": "mock", "name": "Offline Deterministic Mock", "configured": True, "active": settings.LLM_PROVIDER == "mock"},
        {"id": "anthropic", "name": "Anthropic Claude (Messages API)", "configured": bool(settings.ANTHROPIC_API_KEY), "active": settings.LLM_PROVIDER == "anthropic"},
        {"id": "openai", "name": "OpenAI (GPT-4o / GPT-4o-mini)", "configured": bool(settings.OPENAI_API_KEY), "active": settings.LLM_PROVIDER == "openai"},
        {"id": "gemini", "name": "Google Gemini (1.5 Flash / Pro)", "configured": bool(settings.GEMINI_API_KEY), "active": settings.LLM_PROVIDER == "gemini"},
    ]


def greeting_message() -> str:
    from app.schemas import FIELD_REGISTRY
    return (
        "Hi! I'll help you put together a draft Personal Wishes Document. "
        "This is a fictional, non-legal exercise, but I'll ask you a series of "
        "questions just like a real intake would. You can correct any answer "
        "at any time.\n\n" + FIELD_REGISTRY[0].question
    )


def run_turn(
    state: WishesState,
    history: List[ChatMessage],
    user_message: str,
    provider_name: Optional[str] = None,
    turn_index: int = 0,
) -> TurnResult:
    warnings: List[str] = []
    contradiction_warnings: List[str] = []
    active_prov = (provider_name or settings.LLM_PROVIDER or "mock").lower()

    try:
        provider = get_provider(active_prov)
        llm_response = provider.take_turn(state, history, user_message)
    except LLMError as e:
        # Automatic graceful fallback to deterministic mock engine so conversation never crashes
        warnings.append(
            f"Notice: Engine '{active_prov}' unavailable ({e}). "
            f"Automatically switched to offline Deterministic Mock engine."
        )
        provider = MockLLMProvider()
        llm_response = provider.take_turn(state, history, user_message)
        active_prov = "mock"
    except Exception as e:
        warnings.append(f"Notice: Falling back to Deterministic Mock engine ({e}).")
        provider = MockLLMProvider()
        llm_response = provider.take_turn(state, history, user_message)
        active_prov = "mock"

    # 1. Type & schema validation layer
    outcome = validate_updates(llm_response.extracted_updates)
    for rejected in outcome.rejected:
        warnings.append(f"Rejected model output for '{rejected.field}': {rejected.reason}")

    # 2. Contradiction detection layer against confirmed state
    contradictions = detect_contradictions(state, outcome.accepted, user_message)
    contradictory_fields = {c.field for c in contradictions}

    # Separate non-contradictory updates from contradictory ones
    accepted_safe = [u for u in outcome.accepted if u.field not in contradictory_fields]

    for c in contradictions:
        state = mark_contradictory(state, c.field, c.explanation, turn_index=turn_index)
        contradiction_warnings.append(f"Contradiction on '{c.field}': {c.explanation}")

    # 3. Apply safe validated updates into state
    state = apply_updates(state, accepted_safe, turn_index=turn_index, action="llm_extraction")

    # 4. Handle ambiguous fields
    accepted_field_names = {u.field for u in accepted_safe}
    for amb in llm_response.ambiguous_fields:
        if amb.field in accepted_field_names or amb.field in contradictory_fields:
            continue
        state = mark_pending(state, amb.field, amb.reason, turn_index=turn_index)

    # 5. Deterministic derivation of next assistant message
    next_field = next_expected_field(state)
    pending_field = next((f for f in state.status if state.status[f].value == "pending"), None)
    contradictory_field = next((f for f in state.status if state.status[f].value == "contradictory"), None)

    if contradictions:
        # Prompt user specifically about the contradiction
        first_c = contradictions[0]
        assistant_message = f"Wait a moment — {first_c.explanation}\n\n{first_c.suggested_resolution}"
        if "child" in first_c.explanation.lower() or first_c.field == "children_names":
            suggestions = ["I do have children (update)", "No children (ignore)"]
        elif "worldwide" in first_c.explanation.lower():
            suggestions = ["Cover worldwide assets", "Keep single country (UK only)"]
        else:
            suggestions = ["Keep previous answer", "Update with new answer"]
    elif next_field is None:
        if accepted_safe:
            assistant_message = (
                f"{llm_response.assistant_reply.strip()}\n\n"
                "I've updated your draft Personal Wishes Document. "
                "You can review the updated draft on the right, export it (PDF/Markdown/JSON), or correct any other field."
            )
        else:
            reply = llm_response.assistant_reply.strip()
            if reply and reply != "Could you tell me a bit more?":
                assistant_message = reply
            else:
                assistant_message = (
                    "Your draft Personal Wishes Document is already complete and ready for review! "
                    "You can inspect the structured data on the right, export it as a PDF or Markdown, "
                    "or tell me to update any specific field (e.g. 'update my executor to Robert')."
                )
        suggestions = []
    elif next_field == contradictory_field:
        reason = state.contradictions.get(next_field, "A contradiction was detected.")
        assistant_message = f"Let's clarify: {reason} How would you like to proceed with {FIELD_BY_NAME[next_field].question.lower()}?"
        suggestions = FIELD_BY_NAME[next_field].quick_suggestions
    elif next_field == pending_field:
        assistant_message = llm_response.assistant_reply.strip() or FIELD_BY_NAME[next_field].question
        suggestions = FIELD_BY_NAME[next_field].quick_suggestions
    else:
        # Always combine acknowledgement with the next canonical question so the interview moves forward!
        model_reply = llm_response.assistant_reply.strip()
        canonical_question = FIELD_BY_NAME[next_field].question

        if model_reply and model_reply.endswith("?") and (next_field in model_reply.lower() or "what" in model_reply.lower() or "who" in model_reply.lower()):
            assistant_message = model_reply
        elif model_reply and model_reply != canonical_question:
            if not model_reply.endswith(".") and not model_reply.endswith("!") and not model_reply.endswith("?"):
                model_reply += "."
            assistant_message = f"{model_reply}\n\n{canonical_question}"
        else:
            assistant_message = canonical_question
        suggestions = FIELD_BY_NAME[next_field].quick_suggestions

    return TurnResult(
        assistant_message=assistant_message,
        state=state,
        document_preview=generate_document(state),
        is_complete=is_interview_complete(state),
        warnings=warnings,
        quick_suggestions=suggestions,
        active_provider=active_prov,
        contradiction_warnings=contradiction_warnings,
    )
