"""
Structured data models for the Document Intake Assistant.

Two distinct model families live here, deliberately kept apart:

1. WishesState / FieldStatus  -> the application's source of truth about the
   fictional Personal Wishes Document. This is NEVER derived from raw chat
   text; it is only ever updated through validated, typed writes.

2. LLMExtraction / LLMTurnResponse -> the strict contract the language model
   must satisfy on every turn. Nothing from this contract touches WishesState
   until it has been validated field-by-field (see app/validation.py).
"""
from __future__ import annotations

from enum import Enum
from typing import Dict, List, Optional

from pydantic import BaseModel, Field, field_validator


class FieldStatus(str, Enum):
    """Explicit status per field, so 'unknown' is a real value, never absence."""
    MISSING = "missing"           # never asked / never answered
    PENDING = "pending"           # answered, but ambiguous -> needs clarification
    CONFIRMED = "confirmed"       # validated and accepted into the state
    CONTRADICTORY = "contradictory" # conflicting with previously confirmed information


class AuditEntry(BaseModel):
    """An immutable record of a mutation or event on the structured state."""
    timestamp: str
    turn_index: int
    action: str  # e.g. "llm_extraction", "manual_correction", "contradiction_flagged", "sample_loaded"
    field: Optional[str] = None
    old_value: Optional[object] = None
    new_value: Optional[object] = None
    details: Optional[str] = None


# ---------------------------------------------------------------------------
# Canonical field registry. Single source of truth for field names, types,
# and the order the interview asks about them. Both the mock provider and the
# real LLM prompt are generated from this list so the schema can't drift.
# ---------------------------------------------------------------------------
class FieldDef(BaseModel):
    name: str
    type: str  # "str" | "bool" | "list[str]"
    question: str
    required: bool = True
    depends_on: Optional[str] = None      # only ask if this field is truthy
    depends_value: Optional[bool] = None  # required value of depends_on
    quick_suggestions: List[str] = Field(default_factory=list)


FIELD_REGISTRY: List[FieldDef] = [
    FieldDef(name="full_name", type="str",
             question="Let's start with the basics — what is your full legal name?",
             quick_suggestions=[]),
    FieldDef(name="home_address", type="str",
             question="What is your home address?",
             quick_suggestions=[]),
    FieldDef(name="covers_worldwide_assets", type="bool",
             question="Should this document cover your worldwide assets, or only assets in one "
                       "country?",
             quick_suggestions=["Worldwide assets", "Single country (UK only)"]),
    FieldDef(name="has_children", type="bool",
             question="Do you have any children?",
             quick_suggestions=["Yes, I have children", "No, I do not have children"]),
    FieldDef(name="children_names", type="list[str]", required=False,
             question="What are your children's names?",
             depends_on="has_children", depends_value=True,
             quick_suggestions=[]),
    FieldDef(name="executor_name", type="str",
             question="Who would you like to appoint as your executor?",
             quick_suggestions=[]),
    FieldDef(name="executor_relationship", type="str",
             question="What is the executor's relationship to you?",
             quick_suggestions=["Brother", "Sister", "Spouse / Partner", "Son / Daughter", "Close Friend", "Solicitor"]),
    FieldDef(name="specific_gifts", type="list[str]", required=False,
             question="Are there any specific gifts you'd like to leave to anyone? "
                       "(You can say 'no' or 'none'.)",
             quick_suggestions=["No specific gifts", "Family heirloom watch", "Charity donation"]),
    FieldDef(name="additional_wishes", type="str", required=False,
             question="Is there anything else you'd like to add — any additional wishes? "
                       "(You can say 'no' or 'none'.)",
             quick_suggestions=["No additional wishes", "Cremation and simple ceremony", "Burial in family plot"]),
]

FIELD_NAMES = {f.name for f in FIELD_REGISTRY}
FIELD_BY_NAME = {f.name: f for f in FIELD_REGISTRY}

# Fields whose "not applicable" is a legitimate confirmed value (user said "no"/"none")
OPTIONAL_FIELDS = {f.name for f in FIELD_REGISTRY if not f.required}


class WishesState(BaseModel):
    """The structured, authoritative record of the interview."""
    full_name: Optional[str] = None
    home_address: Optional[str] = None
    covers_worldwide_assets: Optional[bool] = None
    has_children: Optional[bool] = None
    children_names: List[str] = Field(default_factory=list)
    executor_name: Optional[str] = None
    executor_relationship: Optional[str] = None
    specific_gifts: List[str] = Field(default_factory=list)
    additional_wishes: Optional[str] = None

    # status[field] tells the UI/engine whether a value is missing, pending
    # clarification, confirmed, or contradictory.
    status: Dict[str, FieldStatus] = Field(
        default_factory=lambda: {name: FieldStatus.MISSING for name in FIELD_NAMES}
    )
    # Human-readable reason a field is pending or contradictory (shown in UI)
    pending_reasons: Dict[str, str] = Field(default_factory=dict)
    contradictions: Dict[str, str] = Field(default_factory=dict)
    audit_trail: List[AuditEntry] = Field(default_factory=list)


class LLMFieldUpdate(BaseModel):
    """One field the model claims to have extracted from the latest message."""
    field: str
    value: object  # validated/coerced downstream against FIELD_REGISTRY type
    confidence: float = 1.0

    @field_validator("field")
    @classmethod
    def known_field(cls, v: str) -> str:
        if v not in FIELD_NAMES:
            raise ValueError(f"Unknown field '{v}'")
        return v


class LLMAmbiguity(BaseModel):
    field: str
    reason: str

    @field_validator("field")
    @classmethod
    def known_field(cls, v: str) -> str:
        if v not in FIELD_NAMES:
            raise ValueError(f"Unknown field '{v}'")
        return v


class LLMTurnResponse(BaseModel):
    """
    The exact JSON contract the LLM (mock or real) must return every turn.
    This is validated with .model_validate(raw_json) before anything in it
    is trusted. See app/validation.py for the second layer of validation
    (type coercion per-field, applied before merging into WishesState).
    """
    extracted_updates: List[LLMFieldUpdate] = Field(default_factory=list)
    ambiguous_fields: List[LLMAmbiguity] = Field(default_factory=list)
    assistant_reply: str


class ChatMessage(BaseModel):
    role: str  # "user" | "assistant"
    content: str


class MessageRequest(BaseModel):
    session_id: str
    message: str


class FieldCorrectionRequest(BaseModel):
    session_id: str
    field: str
    value: object


class TurnResult(BaseModel):
    """What the API returns to the frontend after each turn."""
    assistant_message: str
    state: WishesState
    document_preview: str
    is_complete: bool
    warnings: List[str] = Field(default_factory=list)
    quick_suggestions: List[str] = Field(default_factory=list)
    active_provider: str = "mock"
    contradiction_warnings: List[str] = Field(default_factory=list)


class SessionCreateResult(TurnResult):
    """Same shape as TurnResult, plus the new session's id (only returned once,
    at creation - every subsequent call addresses the session by id in the URL)."""
    session_id: str
