"""
Turns validated WishesState into a human-readable draft document.

Deliberately template-based rather than another LLM call: document
generation from a fully-structured, already-validated state is a mechanical
transformation, and doing it deterministically means the draft can never
contradict or hallucinate beyond what the user actually confirmed.
"""
from __future__ import annotations

from app.schemas import FieldStatus, WishesState

DISCLAIMER = (
    "**This is a FICTIONAL draft document created for demonstration purposes only. "
    "It has no legal effect, is not legal advice, and should never be used as an actual "
    "will or estate planning document. Consult a qualified solicitor for real estate "
    "planning needs.**"
)


def _fmt(value, status: FieldStatus, placeholder: str = "_[not yet provided]_") -> str:
    if status == FieldStatus.PENDING:
        return "_[awaiting clarification]_"
    if status == FieldStatus.CONTRADICTORY:
        return "_[contradiction detected - needs resolution]_"
    if value is None or value == "" or value == []:
        return placeholder
    if isinstance(value, bool):
        return "Yes" if value else "No"
    if isinstance(value, list):
        return ", ".join(value)
    return str(value)


def generate_document(state: WishesState) -> str:
    s = state.status.get

    name = _fmt(state.full_name, s("full_name"))
    address = _fmt(state.home_address, s("home_address"))
    worldwide = _fmt(state.covers_worldwide_assets, s("covers_worldwide_assets"))
    has_children = state.has_children
    children_section = ""
    if s("has_children") == FieldStatus.CONFIRMED:
        if has_children:
            children_section = f"I have the following children: {_fmt(state.children_names, s('children_names'), '_[names not yet provided]_')}."
        else:
            children_section = "I have no children."
    else:
        children_section = "_[not yet provided]_"

    executor_name = _fmt(state.executor_name, s("executor_name"))
    executor_rel = _fmt(state.executor_relationship, s("executor_relationship"))

    gifts = _fmt(state.specific_gifts, s("specific_gifts"), "No specific gifts recorded.")
    wishes = _fmt(state.additional_wishes, s("additional_wishes"), "No additional wishes recorded.")

    doc = f"""# Personal Wishes Document (Draft)

{DISCLAIMER}

---

## 1. Personal Details

**Full name:** {name}

**Home address:** {address}

**Coverage of worldwide assets:** {worldwide}

## 2. Family

{children_section}

## 3. Executor

I appoint **{executor_name}** ({executor_rel}) as the executor of this document.

## 4. Specific Gifts

{gifts}

## 5. Additional Wishes

{wishes}

---

*Draft generated automatically from the information supplied in conversation. \
Fields marked "not yet provided" or "awaiting clarification" have not been confirmed.*
"""
    return doc
