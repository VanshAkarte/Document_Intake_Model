"""
Session storage and the single place WishesState is ever mutated.

Includes:
- Structured state transitions (MISSING -> PENDING/CONTRADICTORY -> CONFIRMED)
- Immutable Audit Trail tracking every change with timestamp and actor
- Session persistence (in-memory with optional local JSON disk backing)
- Sample persona loaders for instant evaluator testing
"""
from __future__ import annotations

from datetime import datetime
import json
import os
import pathlib
import uuid
from typing import Dict, List, Optional

from app.config import settings
from app.schemas import AuditEntry, ChatMessage, FIELD_REGISTRY, FieldStatus, WishesState
from app.validation import ValidatedUpdate


class Session:
    def __init__(self, session_id: Optional[str] = None):
        self.id = session_id or str(uuid.uuid4())
        self.state = WishesState()
        self.history: List[ChatMessage] = []
        self.turn_count: int = 0
        self.active_provider: str = settings.LLM_PROVIDER


def _now_str() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def log_audit(
    state: WishesState,
    action: str,
    field: Optional[str] = None,
    old_value: Optional[object] = None,
    new_value: Optional[object] = None,
    details: Optional[str] = None,
    turn_index: int = 0,
) -> None:
    entry = AuditEntry(
        timestamp=_now_str(),
        turn_index=turn_index,
        action=action,
        field=field,
        old_value=old_value,
        new_value=new_value,
        details=details,
    )
    state.audit_trail.append(entry)


class SessionStore:
    """Session store with in-memory caching and optional JSON persistence."""

    def __init__(self, persistence_file: str = "sessions_db.json"):
        self._sessions: Dict[str, Session] = {}
        self._db_path = pathlib.Path(__file__).resolve().parent.parent / persistence_file
        self._load_from_disk()

    def _load_from_disk(self):
        if not settings.PERSIST_SESSIONS or not self._db_path.exists():
            return
        try:
            with open(self._db_path, "r", encoding="utf-8") as f:
                raw_data = json.load(f)
            for sid, sdata in raw_data.items():
                s = Session(session_id=sid)
                s.state = WishesState.model_validate(sdata.get("state", {}))
                s.history = [ChatMessage.model_validate(m) for m in sdata.get("history", [])]
                s.turn_count = sdata.get("turn_count", 0)
                s.active_provider = sdata.get("active_provider", settings.LLM_PROVIDER)
                self._sessions[sid] = s
        except Exception:
            # graceful fallback if file is corrupted or schema changed
            pass

    def save_to_disk(self):
        if not settings.PERSIST_SESSIONS:
            return
        try:
            dump = {}
            for sid, s in self._sessions.items():
                dump[sid] = {
                    "state": s.state.model_dump(),
                    "history": [m.model_dump() for m in s.history],
                    "turn_count": s.turn_count,
                    "active_provider": s.active_provider,
                }
            with open(self._db_path, "w", encoding="utf-8") as f:
                json.dump(dump, f, indent=2, default=str)
        except Exception:
            pass

    def create(self) -> Session:
        s = Session()
        self._sessions[s.id] = s
        log_audit(s.state, action="session_created", details="New interview session initiated.")
        self.save_to_disk()
        return s

    def get(self, session_id: str) -> Session | None:
        return self._sessions.get(session_id)


def apply_updates(
    state: WishesState,
    updates: List[ValidatedUpdate],
    turn_index: int = 0,
    action: str = "llm_extraction",
) -> WishesState:
    """Merge validated updates into state, marking each touched field CONFIRMED.
    This is the only function allowed to set a field to CONFIRMED."""
    for u in updates:
        old_val = getattr(state, u.field, None)
        setattr(state, u.field, u.value)
        state.status[u.field] = FieldStatus.CONFIRMED
        state.pending_reasons.pop(u.field, None)
        state.contradictions.pop(u.field, None)

        log_audit(
            state,
            action=action,
            field=u.field,
            old_value=old_val,
            new_value=u.value,
            details=f"Field '{u.field}' confirmed.",
            turn_index=turn_index,
        )
    return state


def mark_pending(
    state: WishesState,
    field: str,
    reason: str,
    turn_index: int = 0,
) -> WishesState:
    """A field the model flagged as ambiguous. Only downgrades status if the
    field isn't already confirmed by a *different, later* clear answer in the
    same turn."""
    if state.status.get(field) != FieldStatus.CONFIRMED:
        state.status[field] = FieldStatus.PENDING
        state.pending_reasons[field] = reason
        log_audit(
            state,
            action="ambiguity_flagged",
            field=field,
            details=f"Field marked pending clarification: {reason}",
            turn_index=turn_index,
        )
    return state


def mark_contradictory(
    state: WishesState,
    field: str,
    reason: str,
    turn_index: int = 0,
) -> WishesState:
    """A field that conflicts with previously confirmed state."""
    state.status[field] = FieldStatus.CONTRADICTORY
    state.contradictions[field] = reason
    log_audit(
        state,
        action="contradiction_flagged",
        field=field,
        details=f"Contradiction detected: {reason}",
        turn_index=turn_index,
    )
    return state


def apply_manual_correction(
    state: WishesState,
    field: str,
    value: object,
    turn_index: int = 0,
) -> WishesState:
    """Direct, deterministic correction path from the UI - bypasses the LLM
    entirely. This is the reliability fallback."""
    from app.validation import validate_updates
    from app.schemas import LLMFieldUpdate

    outcome = validate_updates([LLMFieldUpdate(field=field, value=value)])
    if outcome.rejected:
        raise ValueError(outcome.rejected[0].reason)
    return apply_updates(state, outcome.accepted, turn_index=turn_index, action="manual_correction")


def next_expected_field(state: WishesState) -> str | None:
    for f in FIELD_REGISTRY:
        if f.depends_on and getattr(state, f.depends_on, None) is not f.depends_value:
            continue
        if state.status.get(f.name) in (FieldStatus.MISSING, FieldStatus.PENDING, FieldStatus.CONTRADICTORY):
            return f.name
    return None


def is_interview_complete(state: WishesState) -> bool:
    return next_expected_field(state) is None


# Pre-defined test personas for 1-click evaluator testing
SAMPLE_PERSONAS = {
    "watson": {
        "title": "Dr. John H. Watson (Complete Estate)",
        "fields": {
            "full_name": "Dr. John H. Watson",
            "home_address": "221B Baker Street, Marylebone, London, NW1 6XE",
            "covers_worldwide_assets": True,
            "has_children": True,
            "children_names": ["Mary Watson", "James Watson"],
            "executor_name": "Sherlock Holmes",
            "executor_relationship": "close friend and colleague",
            "specific_gifts": ["My Afghan campaign journal to Sherlock Holmes", "Gold pocket watch to Mary Watson"],
            "additional_wishes": "Please arrange a traditional military burial in Hampshire, accompanied by violin music.",
        }
    },
    "sarah": {
        "title": "Sarah Connor (Single Country Estate)",
        "fields": {
            "full_name": "Sarah J. Connor",
            "home_address": "742 Evergreen Terrace, Springfield",
            "covers_worldwide_assets": False,
            "has_children": False,
            "children_names": [],
            "executor_name": "Miles Dyson",
            "executor_relationship": "trusted associate",
            "specific_gifts": ["Charity bequest of $10,000 to Cybernetics Research Fund"],
            "additional_wishes": "Scatter ashes over the Pacific Ocean at sunset; no formal memorial service required.",
        }
    },
}


def load_sample_persona(session: Session, persona_key: str = "watson") -> WishesState:
    """Loads a pre-configured realistic persona into the session for instant testing."""
    if persona_key not in SAMPLE_PERSONAS:
        persona_key = "watson"
    p = SAMPLE_PERSONAS[persona_key]
    fields = p["fields"]

    for k, v in fields.items():
        setattr(session.state, k, v)
        session.state.status[k] = FieldStatus.CONFIRMED
        session.state.pending_reasons.pop(k, None)
        session.state.contradictions.pop(k, None)

    log_audit(
        session.state,
        action="sample_loaded",
        details=f"Loaded demo persona '{p['title']}'. All required fields confirmed.",
        turn_index=session.turn_count,
    )
    store.save_to_disk()
    return session.state


store = SessionStore()
