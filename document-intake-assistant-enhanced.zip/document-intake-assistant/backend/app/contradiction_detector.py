"""
Contradiction Detection Engine for Document Intake Assistant.

Analyzes proposed state updates against already-confirmed structured state
and message context to detect logical, factual, and legal contradictions
before state is corrupted.

Handles:
- Children conflicts (has_children=False vs mentioning children/children names)
- Worldwide asset conflicts (covers_worldwide_assets=False vs overseas assets)
- Executor self-appointment (user appointing themselves as their own executor)
- Sibling / relationship pronoun clashes
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Optional

from app.schemas import FieldStatus, WishesState
from app.validation import ValidatedUpdate


@dataclass
class Contradiction:
    field: str
    conflicting_value: object
    existing_value: object
    explanation: str
    suggested_resolution: str


_CHILDREN_RELATION_WORDS = re.compile(
    r"\b(my son|my daughter|my child|my children|my kids|my boy|my girl)\b",
    re.IGNORECASE,
)

_OVERSEAS_ASSET_KEYWORDS = re.compile(
    r"\b(spain|france|usa|america|india|canada|australia|dubai|overseas|foreign|international|abroad|swiss bank)\b",
    re.IGNORECASE,
)


def detect_contradictions(
    state: WishesState,
    proposed_updates: List[ValidatedUpdate],
    user_message: str,
) -> List[Contradiction]:
    """
    Examines incoming validated updates and the user's message against current confirmed state.
    Returns any detected contradictions with plain-English explanations.
    """
    contradictions: List[Contradiction] = []
    update_dict = {u.field: u.value for u in proposed_updates}
    msg_low = user_message.lower()

    # 1. Contradiction: has_children is False, but children_names are provided
    if state.has_children is False and state.status.get("has_children") == FieldStatus.CONFIRMED:
        if "children_names" in update_dict and update_dict["children_names"]:
            contradictions.append(Contradiction(
                field="children_names",
                conflicting_value=update_dict["children_names"],
                existing_value=False,
                explanation="You previously confirmed you have no children, but named children in your response.",
                suggested_resolution="Would you like to update your family details to confirm you have children, or ignore these names?",
            ))
        elif _CHILDREN_RELATION_WORDS.search(msg_low) and "no child" not in msg_low and "don't have" not in msg_low:
            # User mentioned a child in gifts or wishes while having confirmed no children
            target_field = "specific_gifts" if "specific_gifts" in update_dict else "additional_wishes"
            contradictions.append(Contradiction(
                field=target_field,
                conflicting_value=user_message,
                existing_value=False,
                explanation="You earlier confirmed that you do not have children, but mentioned a child (son/daughter) in your message.",
                suggested_resolution="Should we update your family status to having children, or clarify who this recipient is?",
            ))

    # 2. Contradiction: has_children is True (with names confirmed), but update proposes has_children=False
    if state.has_children is True and state.status.get("has_children") == FieldStatus.CONFIRMED:
        if update_dict.get("has_children") is False and state.children_names:
            contradictions.append(Contradiction(
                field="has_children",
                conflicting_value=False,
                existing_value=state.children_names,
                explanation=f"You previously recorded children ({', '.join(state.children_names)}), but just indicated you have no children.",
                suggested_resolution="Did you mean to remove the previously listed children, or was this an accidental 'no'?",
            ))

    # 3. Contradiction: covers_worldwide_assets is False (UK/single country only), but overseas assets mentioned
    if state.covers_worldwide_assets is False and state.status.get("covers_worldwide_assets") == FieldStatus.CONFIRMED:
        if _OVERSEAS_ASSET_KEYWORDS.search(msg_low):
            target_field = "specific_gifts" if "specific_gifts" in update_dict else "covers_worldwide_assets"
            contradictions.append(Contradiction(
                field=target_field,
                conflicting_value=user_message,
                existing_value="Single country only",
                explanation="You selected single-country coverage only, but mentioned international or overseas properties/assets.",
                suggested_resolution="Should we expand this document to cover worldwide assets instead?",
            ))

    # 4. Contradiction: Appointing self as executor
    if "executor_name" in update_dict and state.full_name and state.status.get("full_name") == FieldStatus.CONFIRMED:
        proposed_exec = str(update_dict["executor_name"]).strip().lower()
        full_name_clean = state.full_name.strip().lower()
        if proposed_exec and (proposed_exec == full_name_clean or proposed_exec in ("myself", "me", "i am")):
            contradictions.append(Contradiction(
                field="executor_name",
                conflicting_value=update_dict["executor_name"],
                existing_value=state.full_name,
                explanation="You cannot appoint yourself as the executor of your own wishes document.",
                suggested_resolution="Please name a trusted relative, friend, or professional representative.",
            ))

    return contradictions
