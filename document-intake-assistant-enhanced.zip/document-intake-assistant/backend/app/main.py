"""
API layer. Thin by design: every route adapts HTTP <-> conversation_engine / state_manager.
Includes session management, multi-provider configuration, persona loaders,
audit log queries, and document export endpoints.
"""
from __future__ import annotations

import pathlib
from typing import Dict, List, Optional
from fastapi import FastAPI, HTTPException, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from app.config import settings
from app.conversation_engine import (
    get_available_providers,
    greeting_message,
    run_turn,
)
from app.document_generator import generate_document
from app.schemas import (
    AuditEntry,
    ChatMessage,
    FIELD_REGISTRY,
    FieldCorrectionRequest,
    MessageRequest,
    SessionCreateResult,
    TurnResult,
    WishesState,
)
from app.state_manager import (
    apply_manual_correction,
    is_interview_complete,
    load_sample_persona,
    next_expected_field,
    store,
)

app = FastAPI(title="Document Intake Assistant API", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _session_or_404(session_id: str):
    session = store.get(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found. Start a new session.")
    return session


@app.post("/api/session", response_model=SessionCreateResult)
def create_session():
    session = store.create()
    greeting = greeting_message()
    session.history.append(ChatMessage(role="assistant", content=greeting))
    first_field = next_expected_field(session.state)
    first_suggestions = [f.quick_suggestions for f in FIELD_REGISTRY if f.name == first_field]
    suggestions = first_suggestions[0] if first_suggestions else []

    return SessionCreateResult(
        session_id=session.id,
        assistant_message=greeting,
        state=session.state,
        document_preview=generate_document(session.state),
        is_complete=False,
        warnings=[],
        quick_suggestions=suggestions,
        active_provider=session.active_provider,
        contradiction_warnings=[],
    )


@app.post("/api/session/{session_id}/message", response_model=TurnResult)
def post_message(session_id: str, body: MessageRequest):
    session = _session_or_404(session_id)
    if body.session_id != session_id:
        raise HTTPException(status_code=400, detail="session_id mismatch between path and body.")
    if not body.message or not body.message.strip():
        raise HTTPException(status_code=400, detail="message must not be empty.")

    session.turn_count += 1
    session.history.append(ChatMessage(role="user", content=body.message))

    result = run_turn(
        state=session.state,
        history=session.history,
        user_message=body.message,
        provider_name=session.active_provider,
        turn_index=session.turn_count,
    )
    session.state = result.state
    session.active_provider = result.active_provider
    session.history.append(ChatMessage(role="assistant", content=result.assistant_message))
    store.save_to_disk()
    return result


@app.get("/api/session/{session_id}/state", response_model=WishesState)
def get_state(session_id: str):
    session = _session_or_404(session_id)
    return session.state


@app.get("/api/session/{session_id}/document")
def get_document(session_id: str):
    session = _session_or_404(session_id)
    return {
        "document": generate_document(session.state),
        "is_complete": is_interview_complete(session.state),
    }


@app.get("/api/session/{session_id}/audit", response_model=List[AuditEntry])
def get_audit(session_id: str):
    session = _session_or_404(session_id)
    return session.state.audit_trail


@app.get("/api/session/{session_id}/history", response_model=List[ChatMessage])
def get_history(session_id: str):
    session = _session_or_404(session_id)
    return session.history


class ProviderChangeRequest(BaseModel):
    provider: str


@app.post("/api/session/{session_id}/provider")
def set_session_provider(session_id: str, body: ProviderChangeRequest):
    session = _session_or_404(session_id)
    prov = body.provider.lower()
    providers = {p["id"]: p for p in get_available_providers()}
    if prov not in providers:
        raise HTTPException(status_code=400, detail=f"Invalid provider. Supported: {list(providers.keys())}")

    prov_info = providers[prov]
    if not prov_info["configured"]:
        session.active_provider = "mock"
        store.save_to_disk()
        return {
            "status": "unconfigured_fallback",
            "active_provider": "mock",
            "message": f"{prov_info['name']} requires an API key in .env. Switched to offline Deterministic Mock engine.",
        }

    session.active_provider = prov
    store.save_to_disk()
    return {"status": "ok", "active_provider": prov, "message": f"Active engine set to {prov.upper()}."}


class SampleLoadRequest(BaseModel):
    persona: str = "watson"


@app.post("/api/session/{session_id}/load-sample", response_model=TurnResult)
def load_sample(session_id: str, body: SampleLoadRequest):
    session = _session_or_404(session_id)
    load_sample_persona(session, body.persona)
    doc = generate_document(session.state)
    msg = (
        f"Loaded demo persona '{body.persona}'. All fields have been populated with valid "
        "sample data and verified against the schema. You can inspect the structured data, "
        "audit trail, and draft document."
    )
    session.history.append(ChatMessage(role="assistant", content=msg))
    store.save_to_disk()
    return TurnResult(
        assistant_message=msg,
        state=session.state,
        document_preview=doc,
        is_complete=True,
        warnings=[],
        quick_suggestions=[],
        active_provider=session.active_provider,
        contradiction_warnings=[],
    )


@app.post("/api/session/{session_id}/correct", response_model=TurnResult)
def correct_field(session_id: str, body: FieldCorrectionRequest):
    session = _session_or_404(session_id)
    if body.session_id != session_id:
        raise HTTPException(status_code=400, detail="session_id mismatch between path and body.")
    session.turn_count += 1
    try:
        session.state = apply_manual_correction(
            session.state, body.field, body.value, turn_index=session.turn_count
        )
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))

    note = f"(Manually updated {body.field}.)"
    session.history.append(ChatMessage(role="user", content=note))
    store.save_to_disk()
    next_field = next_expected_field(session.state)
    suggestions = [f.quick_suggestions for f in FIELD_REGISTRY if f.name == next_field]

    return TurnResult(
        assistant_message=f"Got it, I've updated '{body.field}'.",
        state=session.state,
        document_preview=generate_document(session.state),
        is_complete=is_interview_complete(session.state),
        warnings=[],
        quick_suggestions=suggestions[0] if suggestions else [],
        active_provider=session.active_provider,
        contradiction_warnings=[],
    )


@app.get("/api/session/{session_id}/export/{export_format}")
def export_document(session_id: str, export_format: str):
    session = _session_or_404(session_id)
    doc_text = generate_document(session.state)
    fmt = export_format.lower()

    if fmt in ("markdown", "md"):
        return Response(
            content=doc_text,
            media_type="text/markdown",
            headers={"Content-Disposition": 'attachment; filename="Personal_Wishes_Document.md"'},
        )
    elif fmt == "json":
        data = {
            "session_id": session.id,
            "structured_state": session.state.model_dump(),
            "draft_document": doc_text,
            "is_complete": is_interview_complete(session.state),
            "audit_trail": [a.model_dump() for a in session.state.audit_trail],
        }
        import json as json_lib
        return Response(
            content=json_lib.dumps(data, indent=2, default=str),
            media_type="application/json",
            headers={"Content-Disposition": 'attachment; filename="Personal_Wishes_Data.json"'},
        )
    elif fmt in ("html", "print"):
        # Standalone clean printable document
        html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Personal Wishes Document (Draft)</title>
<style>
  body {{ font-family: 'Georgia', serif; line-height: 1.6; max-width: 800px; margin: 40px auto; padding: 0 20px; color: #111; }}
  h1 {{ border-bottom: 2px solid #2C1B8C; padding-bottom: 8px; font-size: 24px; color: #2C1B8C; }}
  h2 {{ margin-top: 24px; font-size: 18px; color: #1D0F63; border-bottom: 1px solid #ddd; }}
  .disclaimer {{ background: #fff3cd; border-left: 4px solid #ffc107; padding: 12px; margin: 16px 0; font-size: 13px; }}
  .footer {{ margin-top: 40px; font-size: 12px; color: #666; border-top: 1px solid #ccc; padding-top: 12px; }}
  .sig-block {{ margin-top: 50px; display: flex; justify-content: space-between; }}
  .sig-line {{ width: 45%; border-top: 1px solid #333; padding-top: 6px; font-size: 13px; text-align: center; }}
</style>
</head>
<body>
  <div class="disclaimer">
    <strong>DEMONSTRATION DOCUMENT ONLY:</strong> This is a fictional document generated by the WenUp Document Intake Assistant. It has no legal validity and does not constitute a legal will.
  </div>
  <pre style="white-space: pre-wrap; font-family: inherit;">{doc_text}</pre>
  <div class="sig-block">
    <div class="sig-line">Declarant Signature & Date</div>
    <div class="sig-line">Witness Signature & Date</div>
  </div>
  <div class="footer">Generated by WenUp Document Intake Assistant · Session {session.id}</div>
  <script>window.onload = function() {{ window.print(); }}</script>
</body>
</html>"""
        return Response(content=html, media_type="text/html")
    else:
        raise HTTPException(status_code=400, detail="Supported export formats: markdown, json, html")


@app.get("/api/providers")
def get_providers():
    return {"providers": get_available_providers()}


@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "llm_provider": settings.LLM_PROVIDER,
        "available_providers": [p["id"] for p in get_available_providers()],
    }


# --- Serve the static frontend (simple UI, no build step) -------------------
_frontend_dir = pathlib.Path(__file__).resolve().parents[2] / "frontend"
if _frontend_dir.exists():
    app.mount("/", StaticFiles(directory=str(_frontend_dir), html=True), name="frontend")
