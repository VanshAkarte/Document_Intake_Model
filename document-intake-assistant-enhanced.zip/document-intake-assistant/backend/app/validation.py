"""
Second validation layer: even after an LLMTurnResponse has passed pydantic
schema validation (right shape, known field names), the *values* inside it
are still untrusted model output. This module coerces/rejects each value
against the type declared in FIELD_REGISTRY before it is ever allowed to
reach WishesState.

Nothing from the LLM is written to state without going through here first.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

from app.schemas import FIELD_BY_NAME, LLMFieldUpdate


@dataclass
class ValidatedUpdate:
    field: str
    value: object


@dataclass
class RejectedUpdate:
    field: str
    reason: str


@dataclass
class ValidationOutcome:
    accepted: List[ValidatedUpdate]
    rejected: List[RejectedUpdate]


def _coerce_bool(value: object) -> Optional[bool]:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        low = value.strip().lower()
        if low in ("true", "yes", "y"):
            return True
        if low in ("false", "no", "n"):
            return False
    return None


def _coerce_str(value: object) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, str):
        stripped = value.strip()
        return stripped if stripped else None
    return None  # reject non-string types for string fields rather than silently str()-ing them


def _coerce_list_str(value: object) -> Optional[List[str]]:
    if value is None:
        return []
    if isinstance(value, list) and all(isinstance(v, str) for v in value):
        return [v.strip() for v in value if v.strip()]
    if isinstance(value, str):
        # tolerate a raw comma-separated string from a slightly-off model response
        parts = [p.strip() for p in value.split(",") if p.strip()]
        return parts
    return None


def validate_updates(updates: List[LLMFieldUpdate]) -> ValidationOutcome:
    accepted: List[ValidatedUpdate] = []
    rejected: List[RejectedUpdate] = []

    for u in updates:
        field_def = FIELD_BY_NAME.get(u.field)
        if field_def is None:
            rejected.append(RejectedUpdate(u.field, "Unknown field name."))
            continue

        if field_def.type == "bool":
            coerced = _coerce_bool(u.value)
        elif field_def.type == "list[str]":
            coerced = _coerce_list_str(u.value)
        else:  # str
            if u.value is None:
                coerced = None  # explicit null is valid for optional str fields
            else:
                coerced = _coerce_str(u.value)
                if coerced is None and u.value is not None:
                    rejected.append(RejectedUpdate(
                        u.field, f"Expected a string, got {type(u.value).__name__}."
                    ))
                    continue

        if coerced is None and field_def.type == "bool":
            rejected.append(RejectedUpdate(
                u.field, f"Expected true/false, got {u.value!r}."
            ))
            continue
        if coerced is None and field_def.type == "list[str]":
            rejected.append(RejectedUpdate(
                u.field, f"Expected a list of strings, got {u.value!r}."
            ))
            continue

        accepted.append(ValidatedUpdate(field=u.field, value=coerced))

    return ValidationOutcome(accepted=accepted, rejected=rejected)
