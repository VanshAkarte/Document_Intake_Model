"""Tests for enhanced features: audit trail, export formats, sample personas, and NLU edge cases."""
import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.schemas import FieldStatus, WishesState
from app.llm.mock_provider import MockLLMProvider
from app.state_manager import store, load_sample_persona

client = TestClient(app)


def test_mock_provider_handles_no_thats_everything():
    provider = MockLLMProvider()
    state = WishesState()
    # Mark all prior fields confirmed so additional_wishes is target
    for f in ["full_name", "home_address", "covers_worldwide_assets", "has_children", "children_names", "executor_name", "executor_relationship", "specific_gifts"]:
        setattr(state, f, "dummy" if "name" in f or "address" in f else (True if "worldwide" in f or "children" in f else ["child1"] if f == "children_names" else []))
        state.status[f] = FieldStatus.CONFIRMED

    resp = provider.take_turn(state, [], "No that's everything.")
    assert len(resp.extracted_updates) == 1
    assert resp.extracted_updates[0].field == "additional_wishes"
    assert resp.extracted_updates[0].value is None


def test_sample_persona_loading():
    res = client.post("/api/session")
    sid = res.json()["session_id"]

    load_res = client.post(f"/api/session/{sid}/load-sample", json={"persona": "watson"})
    assert load_res.status_code == 200
    data = load_res.json()
    assert data["is_complete"] is True
    assert data["state"]["full_name"] == "Dr. John H. Watson"
    assert data["state"]["has_children"] is True
    assert "Sherlock Holmes" in data["state"]["executor_name"]


def test_audit_trail_endpoint():
    res = client.post("/api/session")
    sid = res.json()["session_id"]

    # Post message
    client.post(f"/api/session/{sid}/message", json={"session_id": sid, "message": "My name is Arthur Dent"})

    # Check audit trail
    audit_res = client.get(f"/api/session/{sid}/audit")
    assert audit_res.status_code == 200
    entries = audit_res.json()
    assert len(entries) >= 2  # session_created + llm_extraction
    actions = [e["action"] for e in entries]
    assert "session_created" in actions
    assert "llm_extraction" in actions


def test_export_endpoints():
    res = client.post("/api/session")
    sid = res.json()["session_id"]
    client.post(f"/api/session/{sid}/load-sample", json={"persona": "watson"})

    # Markdown export
    md_res = client.get(f"/api/session/{sid}/export/markdown")
    assert md_res.status_code == 200
    assert "Personal Wishes Document" in md_res.text
    assert "Dr. John H. Watson" in md_res.text

    # JSON export
    json_res = client.get(f"/api/session/{sid}/export/json")
    assert json_res.status_code == 200
    data = json_res.json()
    assert data["session_id"] == sid
    assert data["structured_state"]["full_name"] == "Dr. John H. Watson"

    # HTML print export
    html_res = client.get(f"/api/session/{sid}/export/html")
    assert html_res.status_code == 200
    assert "<!DOCTYPE html>" in html_res.text
    assert "window.print()" in html_res.text


def test_providers_endpoint_and_switching():
    res = client.get("/api/providers")
    assert res.status_code == 200
    providers = res.json()["providers"]
    ids = [p["id"] for p in providers]
    assert "mock" in ids
    assert "anthropic" in ids
    assert "openai" in ids
    assert "gemini" in ids

    # Test setting provider
    s_res = client.post("/api/session")
    sid = s_res.json()["session_id"]
    switch_res = client.post(f"/api/session/{sid}/provider", json={"provider": "mock"})
    assert switch_res.status_code == 200
    assert switch_res.json()["active_provider"] == "mock"


def test_greeting_at_start_does_not_corrupt_name():
    s_res = client.post("/api/session")
    sid = s_res.json()["session_id"]

    # User says "hi" as first message
    msg_res = client.post(f"/api/session/{sid}/message", json={"session_id": sid, "message": "hi"})
    assert msg_res.status_code == 200
    data = msg_res.json()
    # Name should NOT be "hi"!
    assert data["state"]["full_name"] is None
    assert data["state"]["status"]["full_name"] == "missing"
    assert "full legal name" in data["assistant_message"].lower()


def test_post_completion_greeting_and_update():
    s_res = client.post("/api/session")
    sid = s_res.json()["session_id"]

    # Load Sarah Connor persona (all 9 fields confirmed)
    client.post(f"/api/session/{sid}/load-sample", json={"persona": "sarah"})

    # User types "hi" after loading persona (replicates user screenshot!)
    msg_res = client.post(f"/api/session/{sid}/message", json={"session_id": sid, "message": "hi"})
    assert msg_res.status_code == 200
    data = msg_res.json()
    assert "technical problem" not in data["assistant_message"].lower()
    assert data["is_complete"] is True
    assert "complete" in data["assistant_message"].lower()

    # User then asks to update address
    update_res = client.post(
        f"/api/session/{sid}/message",
        json={"session_id": sid, "message": "update address to 404 Cyberdyne Way, LA"}
    )
    assert update_res.status_code == 200
    u_data = update_res.json()
    assert "404 Cyberdyne Way" in u_data["state"]["home_address"]


def test_unconfigured_provider_graceful_fallback():
    from app.conversation_engine import run_turn
    from app.schemas import WishesState

    state = WishesState()
    # Directly invoke run_turn with openai when no key exists
    res = run_turn(state, [], "My name is John Connor", provider_name="openai")
    # Must NOT fail with "Sorry, I ran into a technical problem"
    assert "technical problem" not in res.assistant_message.lower()
    assert res.state.full_name == "John Connor"
    assert res.active_provider == "mock"
    assert any("unavailable" in w.lower() or "mock" in w.lower() for w in res.warnings)
