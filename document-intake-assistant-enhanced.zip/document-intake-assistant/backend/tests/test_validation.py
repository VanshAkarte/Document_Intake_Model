import json
from pathlib import Path

from app.schemas import LLMTurnResponse, LLMFieldUpdate
from app.validation import validate_updates

FIXTURES = Path(__file__).parent / "fixtures"


def load(name: str) -> dict:
    return json.loads((FIXTURES / name).read_text())


def test_valid_bool_and_string_accepted():
    updates = [
        LLMFieldUpdate(field="full_name", value="Jane Smith"),
        LLMFieldUpdate(field="covers_worldwide_assets", value=True),
    ]
    outcome = validate_updates(updates)
    assert len(outcome.accepted) == 2
    assert len(outcome.rejected) == 0


def test_invalid_types_are_rejected_not_coerced_blindly():
    resp = LLMTurnResponse.model_validate(load("invalid_type_response.json"))
    outcome = validate_updates(resp.extracted_updates)
    # "maybe kind of" is not a parseable bool, and 42 isn't a list of strings
    assert len(outcome.rejected) == 2
    rejected_fields = {r.field for r in outcome.rejected}
    assert rejected_fields == {"covers_worldwide_assets", "children_names"}
    assert outcome.accepted == []


def test_string_list_tolerates_comma_separated_string():
    outcome = validate_updates([LLMFieldUpdate(field="specific_gifts", value="watch, ring, car")])
    assert outcome.accepted[0].value == ["watch", "ring", "car"]


def test_none_is_valid_for_optional_string_field():
    outcome = validate_updates([LLMFieldUpdate(field="additional_wishes", value=None)])
    assert outcome.accepted[0].value is None
    assert outcome.rejected == []


def test_non_string_rejected_for_string_field():
    outcome = validate_updates([LLMFieldUpdate(field="full_name", value=12345)])
    assert outcome.accepted == []
    assert outcome.rejected[0].field == "full_name"
