"""Tests for the Contradiction Detection Engine."""
import pytest
from app.contradiction_detector import detect_contradictions
from app.schemas import FieldStatus, WishesState
from app.validation import ValidatedUpdate


def test_no_children_contradiction_with_children_names():
    state = WishesState()
    state.has_children = False
    state.status["has_children"] = FieldStatus.CONFIRMED

    proposed = [ValidatedUpdate(field="children_names", value=["Alice", "Bob"])]
    conflicts = detect_contradictions(state, proposed, "My kids are Alice and Bob")

    assert len(conflicts) == 1
    assert conflicts[0].field == "children_names"
    assert "previously confirmed you have no children" in conflicts[0].explanation


def test_no_children_contradiction_with_son_in_message():
    state = WishesState()
    state.has_children = False
    state.status["has_children"] = FieldStatus.CONFIRMED

    proposed = [ValidatedUpdate(field="specific_gifts", value=["Watch"])]
    conflicts = detect_contradictions(state, proposed, "I leave my watch to my son")

    assert len(conflicts) == 1
    assert "earlier confirmed that you do not have children" in conflicts[0].explanation


def test_worldwide_assets_contradiction_with_foreign_property():
    state = WishesState()
    state.covers_worldwide_assets = False
    state.status["covers_worldwide_assets"] = FieldStatus.CONFIRMED

    proposed = [ValidatedUpdate(field="specific_gifts", value=["Villa"])]
    conflicts = detect_contradictions(state, proposed, "I leave my villa in Spain to my brother")

    assert len(conflicts) == 1
    assert "single-country coverage only" in conflicts[0].explanation


def test_self_as_executor_contradiction():
    state = WishesState()
    state.full_name = "Jane Smith"
    state.status["full_name"] = FieldStatus.CONFIRMED

    proposed = [ValidatedUpdate(field="executor_name", value="Jane Smith")]
    conflicts = detect_contradictions(state, proposed, "I want to appoint Jane Smith")

    assert len(conflicts) == 1
    assert conflicts[0].field == "executor_name"
    assert "cannot appoint yourself" in conflicts[0].explanation


def test_consistent_updates_produce_no_contradiction():
    state = WishesState()
    state.has_children = True
    state.status["has_children"] = FieldStatus.CONFIRMED

    proposed = [ValidatedUpdate(field="children_names", value=["Alice", "Bob"])]
    conflicts = detect_contradictions(state, proposed, "Alice and Bob")

    assert len(conflicts) == 0
