import json
from pathlib import Path

import pytest
from pydantic import ValidationError

from app.schemas import LLMTurnResponse

FIXTURES = Path(__file__).parent / "fixtures"


def load(name: str) -> dict:
    return json.loads((FIXTURES / name).read_text())


def test_valid_response_parses():
    resp = LLMTurnResponse.model_validate(load("valid_response.json"))
    assert resp.extracted_updates[0].field == "full_name"
    assert resp.extracted_updates[0].value == "Jane Smith"


def test_multi_field_response_parses():
    resp = LLMTurnResponse.model_validate(load("multi_field_response.json"))
    fields = {u.field for u in resp.extracted_updates}
    assert fields == {"executor_name", "executor_relationship"}


def test_ambiguous_response_parses():
    resp = LLMTurnResponse.model_validate(load("ambiguous_response.json"))
    assert resp.extracted_updates == []
    assert resp.ambiguous_fields[0].field == "covers_worldwide_assets"


def test_malformed_response_missing_value_rejected():
    with pytest.raises(ValidationError):
        LLMTurnResponse.model_validate(load("malformed_response.json"))


def test_malformed_response_unknown_field_rejected():
    with pytest.raises(ValidationError):
        LLMTurnResponse.model_validate(load("malformed_bad_field.json"))
