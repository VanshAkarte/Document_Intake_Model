from app.schemas import FieldStatus, WishesState
from app.state_manager import (
    apply_manual_correction,
    apply_updates,
    is_interview_complete,
    mark_pending,
    next_expected_field,
)
from app.validation import ValidatedUpdate


def test_next_expected_field_starts_with_full_name():
    state = WishesState()
    assert next_expected_field(state) == "full_name"


def test_apply_updates_marks_confirmed():
    state = WishesState()
    state = apply_updates(state, [ValidatedUpdate(field="full_name", value="Jane Smith")])
    assert state.full_name == "Jane Smith"
    assert state.status["full_name"] == FieldStatus.CONFIRMED
    assert next_expected_field(state) == "home_address"


def test_children_names_skipped_when_has_children_false():
    state = WishesState()
    state = apply_updates(state, [
        ValidatedUpdate(field="full_name", value="Jane"),
        ValidatedUpdate(field="home_address", value="1 Main St"),
        ValidatedUpdate(field="covers_worldwide_assets", value=True),
        ValidatedUpdate(field="has_children", value=False),
    ])
    # children_names has a depends_on has_children=True, so it should be skipped
    assert next_expected_field(state) == "executor_name"


def test_children_names_asked_when_has_children_true():
    state = WishesState()
    state = apply_updates(state, [
        ValidatedUpdate(field="full_name", value="Jane"),
        ValidatedUpdate(field="home_address", value="1 Main St"),
        ValidatedUpdate(field="covers_worldwide_assets", value=True),
        ValidatedUpdate(field="has_children", value=True),
    ])
    assert next_expected_field(state) == "children_names"


def test_mark_pending_does_not_override_confirmed():
    state = WishesState()
    state = apply_updates(state, [ValidatedUpdate(field="full_name", value="Jane")])
    state = mark_pending(state, "full_name", "some stale ambiguity signal")
    assert state.status["full_name"] == FieldStatus.CONFIRMED


def test_manual_correction_overwrites_confirmed_value():
    state = WishesState()
    state = apply_updates(state, [ValidatedUpdate(field="full_name", value="Jane Smith")])
    state = apply_manual_correction(state, "full_name", "Jane A. Smith")
    assert state.full_name == "Jane A. Smith"
    assert state.status["full_name"] == FieldStatus.CONFIRMED


def test_manual_correction_rejects_invalid_type():
    state = WishesState()
    import pytest
    with pytest.raises(ValueError):
        apply_manual_correction(state, "covers_worldwide_assets", "not a boolean at all")


def test_interview_complete_when_all_required_fields_confirmed():
    state = WishesState()
    updates = [
        ValidatedUpdate(field="full_name", value="Jane"),
        ValidatedUpdate(field="home_address", value="1 Main St"),
        ValidatedUpdate(field="covers_worldwide_assets", value=True),
        ValidatedUpdate(field="has_children", value=False),
        ValidatedUpdate(field="executor_name", value="James"),
        ValidatedUpdate(field="executor_relationship", value="brother"),
        ValidatedUpdate(field="specific_gifts", value=[]),
        ValidatedUpdate(field="additional_wishes", value=None),
    ]
    state = apply_updates(state, updates)
    assert is_interview_complete(state) is True
