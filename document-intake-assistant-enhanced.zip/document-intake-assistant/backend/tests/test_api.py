from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_health():
    r = client.get("/api/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_session_creation_returns_id_and_greeting():
    r = client.post("/api/session")
    assert r.status_code == 200
    body = r.json()
    assert body["session_id"]
    assert body["state"]["full_name"] is None
    assert "name" in body["assistant_message"].lower()


def test_message_against_unknown_session_returns_404():
    r = client.post(
        "/api/session/does-not-exist/message",
        json={"session_id": "does-not-exist", "message": "hello"},
    )
    assert r.status_code == 404


def test_empty_message_rejected():
    session_id = client.post("/api/session").json()["session_id"]
    r = client.post(f"/api/session/{session_id}/message",
                     json={"session_id": session_id, "message": "   "})
    assert r.status_code == 400


def test_session_id_mismatch_rejected():
    session_id = client.post("/api/session").json()["session_id"]
    r = client.post(f"/api/session/{session_id}/message",
                     json={"session_id": "some-other-id", "message": "hi"})
    assert r.status_code == 400


def test_manual_correction_overrides_prior_answer():
    session_id = client.post("/api/session").json()["session_id"]

    r1 = client.post(f"/api/session/{session_id}/message",
                      json={"session_id": session_id, "message": "Jane Smith"})
    assert r1.status_code == 200
    assert r1.json()["state"]["full_name"] == "Jane Smith"

    correct = client.post(f"/api/session/{session_id}/correct",
                           json={"session_id": session_id, "field": "full_name",
                                 "value": "Jane A. Smith"})
    assert correct.status_code == 200
    assert correct.json()["state"]["full_name"] == "Jane A. Smith"


def test_manual_correction_with_invalid_type_returns_422():
    session_id = client.post("/api/session").json()["session_id"]
    r = client.post(f"/api/session/{session_id}/correct",
                     json={"session_id": session_id, "field": "covers_worldwide_assets",
                           "value": "not a boolean"})
    assert r.status_code == 422


def test_full_interview_end_to_end_reaches_completion():
    session_id = client.post("/api/session").json()["session_id"]

    answers = [
        "Jane Smith",              # full_name
        "12 Elm Street, London",   # home_address
        "yes, worldwide",          # covers_worldwide_assets
        "no",                      # has_children
        "My brother James.",       # executor_name + executor_relationship
        "no",                      # specific_gifts
        "no",                      # additional_wishes
    ]
    last = None
    for a in answers:
        last = client.post(f"/api/session/{session_id}/message",
                            json={"session_id": session_id, "message": a})
        assert last.status_code == 200

    body = last.json()
    assert body["state"]["full_name"] == "Jane Smith"
    assert body["state"]["executor_name"] == "James"
    assert body["state"]["executor_relationship"] == "brother"
    assert body["is_complete"] is True
    assert "FICTIONAL" in body["document_preview"]


def test_ambiguous_answer_does_not_silently_advance():
    session_id = client.post("/api/session").json()["session_id"]
    client.post(f"/api/session/{session_id}/message",
                json={"session_id": session_id, "message": "Jane Smith"})
    client.post(f"/api/session/{session_id}/message",
                json={"session_id": session_id, "message": "12 Elm Street"})
    r = client.post(f"/api/session/{session_id}/message",
                     json={"session_id": session_id, "message": "not sure honestly"})
    assert r.json()["state"]["covers_worldwide_assets"] is None
    assert r.json()["state"]["status"]["covers_worldwide_assets"] == "pending"


def test_document_endpoint_reflects_state():
    session_id = client.post("/api/session").json()["session_id"]
    client.post(f"/api/session/{session_id}/message",
                json={"session_id": session_id, "message": "Jane Smith"})
    r = client.get(f"/api/session/{session_id}/document")
    assert r.status_code == 200
    assert "Jane Smith" in r.json()["document"]
