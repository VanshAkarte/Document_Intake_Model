from app.llm.mock_provider import MockLLMProvider
from app.schemas import ChatMessage, WishesState
from app.state_manager import apply_updates
from app.validation import validate_updates


def provider():
    return MockLLMProvider()


def test_extracts_full_name_as_first_answer():
    state = WishesState()
    resp = provider().take_turn(state, [], "My name is Jane Smith")
    fields = {u.field: u.value for u in resp.extracted_updates}
    assert fields["full_name"] == "Jane Smith"


def test_extracts_executor_name_and_relationship_from_example_in_brief():
    # Exact example from the technical brief.
    state = WishesState()
    # advance state to the executor question
    for field, value in [
        ("full_name", "Jane Smith"), ("home_address", "1 Main St"),
        ("covers_worldwide_assets", True), ("has_children", False),
    ]:
        from app.schemas import LLMFieldUpdate
        outcome = validate_updates([LLMFieldUpdate(field=field, value=value)])
        state = apply_updates(state, outcome.accepted)

    resp = provider().take_turn(state, [], "My brother James.")
    fields = {u.field: u.value for u in resp.extracted_updates}
    assert fields["executor_name"] == "James"
    assert fields["executor_relationship"] == "brother"


def test_yes_no_ambiguous_flagged_not_guessed():
    state = WishesState()
    from app.schemas import LLMFieldUpdate
    outcome = validate_updates([LLMFieldUpdate(field="full_name", value="Jane")])
    state = apply_updates(state, outcome.accepted)
    outcome = validate_updates([LLMFieldUpdate(field="home_address", value="1 Main St")])
    state = apply_updates(state, outcome.accepted)

    resp = provider().take_turn(state, [], "hmm not sure")
    assert resp.extracted_updates == []
    assert any(a.field == "covers_worldwide_assets" for a in resp.ambiguous_fields)


def test_multi_field_message_extracts_both():
    state = WishesState()
    resp = provider().take_turn(
        state, [], "My name is Jane Smith"
    )
    assert resp.extracted_updates[0].field == "full_name"


def test_none_answer_for_optional_list_field():
    state = WishesState()
    from app.schemas import LLMFieldUpdate
    for field, value in [
        ("full_name", "Jane"), ("home_address", "1 Main St"),
        ("covers_worldwide_assets", True), ("has_children", False),
        ("executor_name", "James"), ("executor_relationship", "brother"),
    ]:
        outcome = validate_updates([LLMFieldUpdate(field=field, value=value)])
        state = apply_updates(state, outcome.accepted)

    resp = provider().take_turn(state, [], "no")
    fields = {u.field: u.value for u in resp.extracted_updates}
    assert fields["specific_gifts"] == []


def test_multi_field_out_of_order_name_and_address_forward():
    state = WishesState()
    resp = provider().take_turn(
        state, [], "My name is Jane Smith and I live at 12 Elm Street"
    )
    fields = {u.field: u.value for u in resp.extracted_updates}
    assert fields["full_name"] == "Jane Smith"
    assert fields["home_address"] == "12 Elm Street"


def test_multi_field_out_of_order_address_before_name():
    """Regression test: address-then-name ordering used to (a) bleed 'and I'
    into the name capture and (b) falsely match 'son' inside 'Watson' as an
    executor relationship word. Both are asserted against explicitly here."""
    state = WishesState()
    resp = provider().take_turn(
        state, [], "I live at 5 Baker Street and my name is John Watson"
    )
    fields = {u.field: u.value for u in resp.extracted_updates}
    assert fields["full_name"] == "John Watson"
    assert fields["home_address"] == "5 Baker Street"
    assert "executor_relationship" not in fields


def test_yes_no_substring_false_positives_avoided():
    """'unknown' contains 'no' and 'know' contains 'no' as raw substrings -
    regression test for the word-boundary fix in _parse_yes_no."""
    from app.llm.mock_provider import _parse_yes_no
    assert _parse_yes_no("I don't know") is None
    assert _parse_yes_no("unknown to me") is None
    assert _parse_yes_no("yes") is True
    assert _parse_yes_no("no") is False
