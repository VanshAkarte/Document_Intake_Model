from app.document_generator import generate_document
from app.schemas import LLMFieldUpdate, WishesState
from app.state_manager import apply_updates
from app.validation import validate_updates


def _confirm(state: WishesState, field: str, value):
    outcome = validate_updates([LLMFieldUpdate(field=field, value=value)])
    return apply_updates(state, outcome.accepted)


def test_empty_state_shows_placeholders_and_disclaimer():
    doc = generate_document(WishesState())
    assert "not yet provided" in doc
    assert "FICTIONAL" in doc
    assert "not legal advice" in doc


def test_confirmed_fields_appear_in_document():
    state = WishesState()
    state = _confirm(state, "full_name", "Jane Smith")
    state = _confirm(state, "executor_name", "James")
    state = _confirm(state, "executor_relationship", "brother")
    doc = generate_document(state)
    assert "Jane Smith" in doc
    assert "James" in doc
    assert "brother" in doc


def test_pending_field_shows_awaiting_clarification():
    from app.state_manager import mark_pending
    state = WishesState()
    state = mark_pending(state, "covers_worldwide_assets", "unclear answer")
    doc = generate_document(state)
    assert "awaiting clarification" in doc


def test_no_children_renders_correctly():
    state = WishesState()
    state = _confirm(state, "has_children", False)
    doc = generate_document(state)
    assert "I have no children." in doc
