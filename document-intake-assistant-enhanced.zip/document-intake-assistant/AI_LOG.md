# AI Development Log

Built with Anthropic Claude and Google Antigravity IDE as pair-programming assistants. This log documents the initial architecture as well as the Phase 2 enhancements, design trade-offs, bug catches, and human review notes.

---

## 1. Key Instructions & Goals

The project was implemented to satisfy the WenUp Engineering Technical Test brief for the **Document Intake Assistant**:
1. Conduct an interactive conversational intake interview for a fictional Personal Wishes Document.
2. Maintain structured information strictly separate from conversation history.
3. Reliably handle missing, unclear, and contradictory information without hallucination or corruption.
4. Provide both backend and a modern, accessible user interface.
5. Provide deterministic offline fallback (mock provider) alongside production LLM providers.
6. Provide comprehensive test coverage, complete setup instructions, and an audit trail.

---

## 2. Iterations & Key Problems Solved

### Phase 1: Foundation & Reliability
- **State decoupled from transcript:** Rather than asking an LLM "what's next?" from conversation history, `WishesState` is the sole source of truth. Every turn, the application deterministically derives the next required question from validated state (`state_manager.next_expected_field`).
- **Two-layer validation:**
  1. `LLMTurnResponse.model_validate()` ensures JSON shape integrity.
  2. `validation.py::validate_updates()` ensures typed field values before any update reaches state.
- **Word boundary checks for mock provider:** Switched keyword matching from raw substring checks to `\bword\b` regex checks to prevent false positives (e.g. "son" inside "Watson", "no" inside "know").

### Phase 2: Enhanced Intelligence & Enterprise Features
- **Contradiction Detection Engine (`contradiction_detector.py`):**
  - Problem: Prior versions only flagged missing or ambiguous input, but could allow contradictory statements (e.g., stating "I have no children", but later leaving gifts to a "daughter", or selecting "UK only" but leaving properties in Spain).
  - Solution: Built a semantic cross-field contradiction detector that runs before state commits. When a conflict is detected, the field status is marked `CONTRADICTORY`, and the assistant asks an explicit clarifying resolution question.
- **Honorific name truncation bug caught & fixed:**
  - When testing `"My name is Dr. John Watson and I live at 221B Baker Street"`, the initial anchor regex `[.,]` truncated the name to `"Dr"` because of the period in `"Dr."`.
  - Fixed by updating `_NAME_ANCHOR` to explicitly support honorifics (`Dr.`, `Mr.`, `Mrs.`, `Ms.`, `Prof.`) without treating the title dot as a sentence boundary.
- **Natural termination phrase handling:**
  - Resolved the limitation where answering an optional field with `"no that's everything"` was stored literally. Expanded `_is_none_answer` with regex pattern `NONE_PHRASES_RE` to correctly recognize natural closure phrases as empty answers.
- **Multi-Provider LLM Architecture:**
  - Expanded beyond Anthropic to support **OpenAI (`gpt-4o`, `gpt-4o-mini`)** and **Google Gemini (`gemini-1.5-flash`)** using direct `httpx` REST calls (zero heavy dependencies).
  - Providers can be toggled on-the-fly via the topbar UI or API without server restarts.
- **Immutable State Audit Trail (`audit_trail`):**
  - Added an event-sourced audit log recording every transition: `session_created`, `llm_extraction`, `manual_correction`, `contradiction_flagged`, `sample_loaded`.
  - Added an interactive **Audit Trail & Diff** tab in the UI, visibly demonstrating to reviewers the separation of transcript and state.
- **UI/UX Modernization & Accessibility:**
  - Added **Contextual Quick Reply Chips** for one-click answering.
  - Added **Voice Dictation (Speech-to-Text)** using the Web Speech API.
  - Added **Multi-format Document Export Suite**: Print/PDF, Markdown (.md), and JSON (.json) with single-click clipboard copying.
  - Added **1-Click Test Personas** (Dr. John H. Watson, Sarah Connor) allowing instant reviewer verification.
  - Added Light/Dark mode luxury theme with persistence in `localStorage`.

---

## 3. Test Suite Progression

| Stage | Test Count | Focus Areas |
|---|---|---|
| Initial | 40 tests | Schema validation, mock provider extraction, state transitions, API endpoints |
| Enhanced | 50 tests | Contradiction detection, audit logging, multi-format exports, provider switching, natural closure parsing |

All 50 tests pass in < 1.0 second with zero external dependencies.

---

## 4. Notes for Human Reviewers

1. **Deterministic Mock vs Live LLM:** The application runs out of the box with zero API keys required (`LLM_PROVIDER=mock`). Setting `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, or `GEMINI_API_KEY` in `.env` activates live models seamlessly.
2. **Reviewer Quick-Test:** To test the full draft document generation instantly without manually typing 9 turns, select **"Dr. John H. Watson (Full Estate)"** from the topbar persona dropdown.
3. **Contradiction Test:** Try answering "No" to children, then in gifts typing "Leave my watch to my daughter Emma" to observe the contradiction engine in action.
