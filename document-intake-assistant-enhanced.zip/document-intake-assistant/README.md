# Document Intake Assistant (v2.0 Enhanced)

A conversational AI web application that interviews a user, maintains an authoritative structured state strictly decoupled from the chat transcript, detects and resolves contradictions, and generates a fictional **Personal Wishes Document** with a multi-format export suite. Built for the WenUp engineering technical test.

> ⚠️ **Disclaimer:** This produces a fictional demo document. It is **not** legal advice and has no legal effect.

---

## 1. Project Structure

```
document-intake-assistant/
├── backend/
│   ├── app/
│   │   ├── main.py                  # FastAPI routes (API layer, static files & exports)
│   │   ├── schemas.py               # Pydantic models: WishesState, AuditEntry, LLM contracts
│   │   ├── config.py                # Env-driven settings (Mock, Anthropic, OpenAI, Gemini)
│   │   ├── conversation_engine.py   # Turn orchestrator: LLM -> validation -> contradiction check -> next question
│   │   ├── contradiction_detector.py# Semantic conflict detection engine (cross-field logic)
│   │   ├── state_manager.py         # Session storage, audit logging, & persona loaders
│   │   ├── validation.py            # Per-field type validation/coercion
│   │   ├── document_generator.py    # Deterministic Markdown generator: state -> draft document
│   │   └── llm/
│   │       ├── base.py              # LLMProvider abstract interface
│   │       ├── mock_provider.py     # Deterministic, offline NLU provider (default, 0 keys needed)
│   │       ├── anthropic_provider.py# Anthropic Claude Messages API
│   │       ├── openai_provider.py   # OpenAI GPT-4o / GPT-4o-mini REST provider
│   │       └── gemini_provider.py   # Google Gemini 1.5/2.0 REST provider
│   ├── tests/                       # 50 comprehensive pytest tests
│   │   ├── test_api.py              # API round trips & validation errors
│   │   ├── test_contradiction_detector.py # Semantic contradiction tests
│   │   ├── test_enhanced_features.py# Audit trail, persona loaders, exports, NLU edge cases
│   │   ├── test_document_generator.py # Markdown document formatting
│   │   ├── test_llm_contract.py     # Pydantic schema validation & fixtures
│   │   ├── test_mock_provider.py    # Rule-based extraction & regex boundary tests
│   │   ├── test_state_manager.py    # State transitions & dependency skipping
│   │   ├── test_validation.py       # Type coercion & rejection rules
│   │   └── fixtures/                # Valid, ambiguous, and malformed JSON fixtures
│   ├── .env.example                 # Configuration template
│   ├── pytest.ini                   # Pytest configuration
│   └── requirements.txt             # Python dependencies
├── frontend/
│   ├── index.html                   # Semantic HTML5 layout with voice input & tabs
│   ├── style.css                    # Luxury glassmorphic theme (Dark/Light mode + Print CSS)
│   └── script.js                    # Reactive vanilla JS, SpeechRecognition, & export handlers
├── AI_LOG.md                        # Detailed log of AI pair-programming iterations & bug catches
└── README.md                        # Complete setup, architecture, and production notes
```

---

## 2. Quick Start

Requires **Python 3.11+**. No API key is required — the application runs fully offline with a deterministic mock NLU provider by default.

### Setup & Run

```bash
# 1. Navigate to backend
cd backend

# 2. Create and activate a virtual environment
python -m venv .venv
# On Windows:
.venv\Scripts\activate
# On macOS / Linux:
source .venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Copy environment configuration
cp .env.example .env
# (Defaults to LLM_PROVIDER=mock — runs immediately without any credentials)

# 5. Start the server
uvicorn app.main:app --reload --port 8000
```

Open **[http://localhost:8000](http://localhost:8000)** in your browser. The backend serves the frontend directly. Interactive API docs (Swagger UI) are available at **[http://localhost:8000/docs](http://localhost:8000/docs)**.

---

## 3. Running with Live LLMs (Optional)

You can switch the LLM provider at any time either in `backend/.env` OR dynamically directly in the frontend topbar selector:

```bash
# Option A: Anthropic Claude
LLM_PROVIDER=anthropic
ANTHROPIC_API_KEY=sk-ant-...
ANTHROPIC_MODEL=claude-sonnet-4-6

# Option B: OpenAI GPT-4o
LLM_PROVIDER=openai
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4o-mini

# Option C: Google Gemini
LLM_PROVIDER=gemini
GEMINI_API_KEY=AIza...
GEMINI_MODEL=gemini-1.5-flash
```

All providers implement the exact same `LLMProvider` interface (`app/llm/base.py`) and adhere to the strict `LLMTurnResponse` Pydantic schema contract.

---

## 4. Running the Tests

The test suite contains **50 automated tests** covering validation, state transitions, contradiction detection, mock extraction, audit trail logging, and API endpoints:

```bash
cd backend
pytest -v
```

Execution takes less than 1.0 second.

---

## 5. Architecture & Key Design Decisions

### 1. Structured State is the Source of Truth, Not the Chat History
`WishesState` (`app/schemas.py`) is an authoritative typed model. Conversation history is kept purely for conversational context fed back into prompts. The application never inspects chat text to decide what information is "known" or what to ask next.

### 2. Contradiction Detection Engine (`app/contradiction_detector.py`)
Rather than blindly accepting statements that conflict with previously confirmed facts, a dedicated contradiction engine inspects incoming updates against current state:
- **Family Status Conflicts:** Catching situations where `has_children=False` was confirmed, but the user later lists children's names or mentions leaving gifts to a son/daughter.
- **Geographic Scope Conflicts:** Catching situations where `covers_worldwide_assets=False` (UK only) was confirmed, but overseas properties (e.g. "villa in Spain", "overseas accounts") are mentioned.
- **Legal Self-Appointment:** Catching when a user attempts to appoint themselves as their own executor.

When a contradiction is detected, the field status is flagged as `CONTRADICTORY`, and the assistant asks an explicit clarifying resolution question.

### 3. Two-Layer Validation Barrier
1. **Schema Layer (`LLMTurnResponse.model_validate`):** Verifies that the JSON has the exact shape, known field names, and expected nesting.
2. **Type Coercion Layer (`validation.py::validate_updates`):** Verifies each individual value against the field's declared type. Invalid or hallucinated types are rejected and never reach state.

### 4. Deterministic Flow Control
After every turn, `conversation_engine.py` re-derives the actual next question deterministically from the validated state (`state_manager.next_expected_field`). The interview can never skip a required field, desync, or repeatedly ask for already-confirmed data.

### 5. Non-LLM Manual Correction Escape Hatch
Every field in the structured data dashboard is directly editable (`POST /api/session/{id}/correct`), bypassing NLU completely while still passing through the validation layer.

### 6. Event-Sourced Immutable Audit Trail
Every state transition logs an `AuditEntry` (`timestamp`, `turn_index`, `action`, `field`, `old_value`, `new_value`, `details`). Reviewers can inspect the live timeline in the **Audit Trail & Diff** tab to see proof of state mutation decoupling.

---

## 6. API Reference

| Method | Path | Description |
|---|---|---|
| `POST` | `/api/session` | Initialize a new interview session. Returns greeting, empty state, and suggestions. |
| `POST` | `/api/session/{id}/message` | Send user message. Returns updated state, next question, document preview, warnings, and suggestions. |
| `GET` | `/api/session/{id}/state` | Fetch current structured `WishesState`. |
| `GET` | `/api/session/{id}/document` | Fetch generated draft document text and completeness status. |
| `POST` | `/api/session/{id}/correct` | Manually correct a field value (bypasses LLM). |
| `GET` | `/api/session/{id}/audit` | Retrieve full immutable state mutation audit trail. |
| `GET` | `/api/session/{id}/history` | Retrieve full chat message history. |
| `POST` | `/api/session/{id}/load-sample` | Quick-load a pre-configured persona (`watson` or `sarah`). |
| `GET` | `/api/session/{id}/export/{format}` | Export document as `markdown`, `json`, or printable `html`. |
| `GET` | `/api/providers` | List available extraction providers and configuration status. |
| `POST` | `/api/session/{id}/provider` | Switch active provider for the session (`mock`, `anthropic`, `openai`, `gemini`). |
| `GET` | `/api/health` | Liveness health check. |

---

## 7. Interactive Reviewer Features

1. **⚡ 1-Click Test Persona Loader:**
   Use the **"Quick Test Persona..."** dropdown in the topbar to instantly load **Dr. John H. Watson** or **Sarah Connor**. All 9 fields populate immediately, completing the interview and generating the full draft document.
2. **🎙️ Speech-to-Text Voice Dictation:**
   Click the microphone button next to the chat input to speak answers naturally using the browser's native Web Speech API.
3. **💡 Contextual Quick Suggestion Chips:**
   Above the input bar, smart reply chips appear tailored to the current question (e.g. `[Worldwide assets]`, `[Single country (UK only)]`, `[Yes, I have children]`, `[No children]`).
4. **📄 Multi-Format Export Suite:**
   In the **Draft Document** tab, click **Print / PDF**, **Markdown**, **JSON**, or **Copy** to export your document.
5. **🌓 Dark / Light Mode Toggle:**
   Click the moon/sun icon in the topbar to toggle themes with `localStorage` persistence.

---

## 8. What I Would Improve for Production

1. **Distributed Persistence & Encryption:**
   Replace the local JSON/in-memory store with PostgreSQL or Redis, encrypting all PII (Personally Identifiable Information) and wishes at rest using AES-256 or envelope encryption.
2. **Streaming Tokens with Speculative Decoding:**
   Stream tokens for perceived responsiveness while maintaining a background buffer to validate complete JSON structures before committing state changes.
3. **Authentication & Multi-Tenant Access Control:**
   Integrate OAuth2 / JWT authentication with role-based access control, allowing users to save, resume, and share documents with solicitors securely.
4. **E-Signature & Legal Verification Integration:**
   Integrate DocuSign or Adobe Sign API for formal legal witness signing workflows once real legal counsel has approved the document.
5. **Comprehensive Telemetry & Observability:**
   Implement OpenTelemetry tracing to track token latency, extraction error rates, and prompt drift across different foundation models.
6. **Multi-Language Internationalization (i18n):**
   Extract string bundles to support multi-lingual conversational intake in Spanish, French, German, and Hindi.
