/* Document Intake Assistant - Frontend Logic (v2.0 Enhanced)
 * Real-time Conversational Intake, Structured State Synchronization,
 * Speech-to-Text Voice Dictation, Multi-Provider Switching, Contradiction Alerting,
 * Audit Trail Logging, and Document Export Suite.
 */
(() => {
  "use strict";

  const API_BASE = "/api";

  // Canonical field registry mirror for display & labels
  const FIELDS = [
    { name: "full_name", label: "Full Name", type: "str", category: "Personal" },
    { name: "home_address", label: "Home Address", type: "str", category: "Personal" },
    { name: "covers_worldwide_assets", label: "Covers Worldwide Assets", type: "bool", category: "Scope" },
    { name: "has_children", label: "Has Children", type: "bool", category: "Family" },
    { name: "children_names", label: "Children's Names", type: "list", category: "Family", dependsOn: "has_children" },
    { name: "executor_name", label: "Executor Name", type: "str", category: "Executor" },
    { name: "executor_relationship", label: "Executor Relationship", type: "str", category: "Executor" },
    { name: "specific_gifts", label: "Specific Gifts", type: "list", category: "Bequests" },
    { name: "additional_wishes", label: "Additional Wishes", type: "str", category: "Wishes" },
  ];

  const REQUIRED_FIELDS = FIELDS.filter(f => !["children_names", "specific_gifts", "additional_wishes"].includes(f.name));

  let sessionId = null;
  let currentState = null;
  let isRecording = false;
  let recognition = null;

  // DOM Elements
  const el = {
    chatLog: document.getElementById("chat-log"),
    chatForm: document.getElementById("chat-form"),
    chatInput: document.getElementById("chat-input"),
    sendBtn: document.getElementById("send-btn"),
    micBtn: document.getElementById("mic-btn"),
    suggestionsRow: document.getElementById("suggestions-row"),
    fieldList: document.getElementById("field-list"),
    documentPreview: document.getElementById("document-preview"),
    docStatusBadge: document.getElementById("doc-status-badge"),
    auditList: document.getElementById("audit-list"),
    warningBanner: document.getElementById("warning-banner"),
    contradictionBanner: document.getElementById("contradiction-banner"),
    progressLabel: document.getElementById("progress-label"),
    progressPercent: document.getElementById("progress-percent"),
    progressFill: document.getElementById("progress-fill"),
    restartBtn: document.getElementById("restart-btn"),
    themeToggle: document.getElementById("theme-toggle"),
    themeIcon: document.getElementById("theme-icon"),
    providerSelect: document.getElementById("provider-select"),
    personaSelect: document.getElementById("persona-select"),
    tabBtns: document.querySelectorAll(".tab-btn"),
    tabContents: document.querySelectorAll(".tab-content"),
    btnPrintDoc: document.getElementById("btn-print-doc"),
    btnExportMd: document.getElementById("btn-export-md"),
    btnExportJson: document.getElementById("btn-export-json"),
    btnCopyDoc: document.getElementById("btn-copy-doc"),
    toastContainer: document.getElementById("toast-container"),
    modalBackdrop: document.getElementById("edit-modal"),
    modalTitle: document.getElementById("edit-modal-title"),
    modalBody: document.getElementById("edit-modal-body"),
    modalSave: document.getElementById("edit-save"),
    modalCancel: document.getElementById("edit-cancel"),
    modalCloseX: document.getElementById("modal-close-x"),
  };

  // --- Theme Management ------------------------------------------------
  function initTheme() {
    const saved = localStorage.getItem("wenup_theme") || "light";
    document.documentElement.setAttribute("data-theme", saved);
    el.themeIcon.textContent = saved === "dark" ? "☀️" : "🌙";
  }

  el.themeToggle.addEventListener("click", () => {
    const current = document.documentElement.getAttribute("data-theme") || "light";
    const next = current === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", next);
    localStorage.setItem("wenup_theme", next);
    el.themeIcon.textContent = next === "dark" ? "☀️" : "🌙";
  });

  // --- Toast Notifications ---------------------------------------------
  function showToast(message, duration = 3000) {
    const toast = document.createElement("div");
    toast.className = "toast";
    toast.innerHTML = `<span>✓</span> <span>${escapeHtml(message)}</span>`;
    el.toastContainer.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translateX(20px)";
      setTimeout(() => toast.remove(), 250);
    }, duration);
  }

  // --- Tabs ------------------------------------------------------------
  el.tabBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      el.tabBtns.forEach(b => {
        b.classList.remove("active");
        b.setAttribute("aria-selected", "false");
      });
      el.tabContents.forEach(c => c.classList.remove("active"));
      btn.classList.add("active");
      btn.setAttribute("aria-selected", "true");
      document.getElementById(`tab-${btn.dataset.tab}`).classList.add("active");

      if (btn.dataset.tab === "audit") {
        fetchAndRenderAudit();
      }
    });
  });

  // --- Speech-to-Text Voice Dictation ----------------------------------
  function initSpeechRecognition() {
    const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRec) {
      el.micBtn.style.display = "none";
      return;
    }
    recognition = new SpeechRec();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = "en-US";

    recognition.onstart = () => {
      isRecording = true;
      el.micBtn.classList.add("recording");
      showToast("Listening... speak your answer");
    };

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      if (transcript) {
        el.chatInput.value = (el.chatInput.value ? el.chatInput.value + " " : "") + transcript;
        el.chatInput.focus();
      }
    };

    recognition.onerror = () => {
      isRecording = false;
      el.micBtn.classList.remove("recording");
    };

    recognition.onend = () => {
      isRecording = false;
      el.micBtn.classList.remove("recording");
    };

    el.micBtn.addEventListener("click", () => {
      if (!recognition) return;
      if (isRecording) {
        recognition.stop();
      } else {
        recognition.start();
      }
    });
  }

  // --- Chat Stream -----------------------------------------------------
  function addMessage(role, text) {
    const div = document.createElement("div");
    div.className = `msg ${role}`;

    const avatar = document.createElement("div");
    avatar.className = "msg-avatar";
    avatar.innerHTML = role === "assistant" ? "W" : "👤";

    const bubble = document.createElement("div");
    bubble.className = "msg-bubble";
    bubble.textContent = text;

    div.appendChild(avatar);
    div.appendChild(bubble);
    el.chatLog.appendChild(div);
    el.chatLog.scrollTop = el.chatLog.scrollHeight;
    return div;
  }

  function addSystemNote(text) {
    const div = document.createElement("div");
    div.className = "msg system-note";
    div.textContent = text;
    el.chatLog.appendChild(div);
    el.chatLog.scrollTop = el.chatLog.scrollHeight;
  }

  function showTyping() {
    const div = document.createElement("div");
    div.className = "msg typing";
    div.id = "typing-indicator";
    div.innerHTML = `
      <div class="msg-avatar">W</div>
      <div class="msg-bubble">
        <span></span><span></span><span></span>
      </div>`;
    el.chatLog.appendChild(div);
    el.chatLog.scrollTop = el.chatLog.scrollHeight;
  }

  function hideTyping() {
    const t = document.getElementById("typing-indicator");
    if (t) t.remove();
  }

  function renderSuggestions(suggestions) {
    el.suggestionsRow.innerHTML = "";
    if (!suggestions || suggestions.length === 0) {
      el.suggestionsRow.style.display = "none";
      return;
    }
    el.suggestionsRow.style.display = "flex";
    suggestions.forEach(s => {
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = "suggestion-chip";
      chip.textContent = s;
      chip.addEventListener("click", () => {
        el.chatInput.value = s;
        el.chatForm.dispatchEvent(new Event("submit"));
      });
      el.suggestionsRow.appendChild(chip);
    });
  }

  function showWarnings(warnings) {
    if (!warnings || warnings.length === 0) {
      el.warningBanner.classList.add("hidden");
      el.warningBanner.innerHTML = "";
      return;
    }
    el.warningBanner.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:12px; width:100%;">
        <div><strong>Notice:</strong> ${warnings.map(escapeHtml).join(" · ")}</div>
        <button type="button" style="background:transparent; border:none; font-size:14px; cursor:pointer; color:inherit; opacity:0.8; padding:0 4px;" title="Dismiss" onclick="document.getElementById('warning-banner').classList.add('hidden')">✕</button>
      </div>`;
    el.warningBanner.classList.remove("hidden");
  }

  function showContradictions(contradictions) {
    if (!contradictions || contradictions.length === 0) {
      el.contradictionBanner.classList.add("hidden");
      return;
    }
    el.contradictionBanner.innerHTML = `
      <span style="font-size: 16px;">⚠️</span>
      <div>
        <strong>Contradiction Detected:</strong> ${contradictions.map(escapeHtml).join(" ")}
      </div>`;
    el.contradictionBanner.classList.remove("hidden");
  }

  // --- State Panel -----------------------------------------------------
  function fieldDisplayValue(field) {
    const raw = currentState[field.name];
    const status = currentState.status[field.name];

    if (status === "contradictory") {
      const reason = currentState.contradictions?.[field.name] || "Contradiction detected";
      return { text: reason, class: "contradictory" };
    }
    if (status === "pending") {
      const reason = currentState.pending_reasons?.[field.name] || "Awaiting clarification…";
      return { text: reason, class: "empty" };
    }
    if (field.type === "bool") {
      if (raw === null || raw === undefined) return { text: "Not yet provided", class: "empty" };
      return { text: raw ? "Yes" : "No", class: "" };
    }
    if (field.type === "list") {
      if (!raw || raw.length === 0) {
        return status === "confirmed" ? { text: "None recorded", class: "" } : { text: "Not yet provided", class: "empty" };
      }
      return { text: raw.join(", "), class: "" };
    }
    if (raw === null || raw === undefined || raw === "") {
      return status === "confirmed" ? { text: "None recorded", class: "" } : { text: "Not yet provided", class: "empty" };
    }
    return { text: String(raw), class: "" };
  }

  function fieldApplicable(field) {
    if (!field.dependsOn) return true;
    return currentState[field.dependsOn] === true;
  }

  function renderState() {
    el.fieldList.innerHTML = "";
    let confirmedRequired = 0;

    FIELDS.forEach(field => {
      if (!fieldApplicable(field)) return;

      const status = currentState.status[field.name];
      if (REQUIRED_FIELDS.some(r => r.name === field.name) && status === "confirmed") {
        confirmedRequired++;
      }

      const { text, class: valClass } = fieldDisplayValue(field);

      const card = document.createElement("div");
      card.className = "field-card";
      card.setAttribute("role", "button");
      card.setAttribute("tabindex", "0");
      card.setAttribute("aria-label", `Edit ${field.label}`);

      const left = document.createElement("div");
      left.className = "field-card-left";

      const dot = document.createElement("span");
      dot.className = `status-dot ${status}`;

      const meta = document.createElement("div");
      meta.className = "field-meta";
      meta.innerHTML = `
        <span class="field-label">${field.label}</span>
        <span class="field-val-text ${valClass}">${escapeHtml(text)}</span>
      `;

      left.appendChild(dot);
      left.appendChild(meta);

      const editBtn = document.createElement("button");
      editBtn.type = "button";
      editBtn.className = "field-edit-btn";
      editBtn.textContent = "Edit";

      card.appendChild(left);
      card.appendChild(editBtn);

      const handleOpen = () => openEditModal(field);
      card.addEventListener("click", handleOpen);
      card.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          handleOpen();
        }
      });

      el.fieldList.appendChild(card);
    });

    const total = REQUIRED_FIELDS.length;
    const pct = Math.round((confirmedRequired / total) * 100);
    el.progressLabel.textContent = `${confirmedRequired} of ${total} confirmed`;
    el.progressPercent.textContent = `${pct}%`;
    el.progressFill.style.width = `${pct}%`;

    if (confirmedRequired === total) {
      el.docStatusBadge.textContent = "✓ All Required Fields Confirmed";
      el.docStatusBadge.classList.add("complete");
    } else {
      el.docStatusBadge.textContent = "Draft in Progress";
      el.docStatusBadge.classList.remove("complete");
    }
  }

  // --- Document Preview ------------------------------------------------
  function renderMarkdown(md) {
    const lines = md.split("\n");
    let html = "";
    let firstBoldDone = false;
    for (const line of lines) {
      if (line.startsWith("# ")) {
        html += `<h1>${escapeHtml(line.slice(2))}</h1>`;
      } else if (line.startsWith("## ")) {
        html += `<h2>${escapeHtml(line.slice(3))}</h2>`;
      } else if (line.trim() === "---") {
        html += "<hr/>";
      } else if (line.trim() === "") {
        continue;
      } else {
        let processed = inlineMd(escapeHtml(line));
        if (!firstBoldDone && line.startsWith("**This is a FICTIONAL")) {
          html += `<div class="doc-disclaimer">${processed}</div>`;
          firstBoldDone = true;
        } else {
          html += `<p>${processed}</p>`;
        }
      }
    }
    return html;
  }

  function inlineMd(s) {
    return s
      .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
      .replace(/_(.+?)_/g, "<em>$1</em>");
  }

  function escapeHtml(s) {
    return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  function renderDocument(text) {
    el.documentPreview.innerHTML = renderMarkdown(text);
  }

  // --- Audit Trail -----------------------------------------------------
  async function fetchAndRenderAudit() {
    if (!sessionId) return;
    try {
      const entries = await apiGet(`/session/${sessionId}/audit`);
      el.auditList.innerHTML = "";
      if (!entries || entries.length === 0) {
        el.auditList.innerHTML = `<div class="state-sub">No audit entries yet.</div>`;
        return;
      }

      entries.slice().reverse().forEach(e => {
        const item = document.createElement("div");
        item.className = "audit-item";

        const time = document.createElement("div");
        time.className = "audit-time";
        time.textContent = e.timestamp.split(" ")[1] || e.timestamp;

        const content = document.createElement("div");
        content.className = "audit-content";

        const badge = document.createElement("span");
        badge.className = "audit-badge";
        badge.textContent = e.action.replace("_", " ");

        const desc = document.createElement("div");
        desc.style.fontSize = "13px";
        desc.textContent = e.details || (e.field ? `Field '${e.field}' updated.` : "");

        content.appendChild(badge);
        content.appendChild(desc);

        if (e.old_value !== null && e.new_value !== null && e.field) {
          const diff = document.createElement("div");
          diff.className = "audit-diff";
          diff.textContent = `${JSON.stringify(e.old_value)} ➔ ${JSON.stringify(e.new_value)}`;
          content.appendChild(diff);
        }

        item.appendChild(time);
        item.appendChild(content);
        el.auditList.appendChild(item);
      });
    } catch (err) {
      el.auditList.innerHTML = `<div class="state-sub">Could not fetch audit trail.</div>`;
    }
  }

  // --- API Calls -------------------------------------------------------
  async function apiPost(path, body) {
    const res = await fetch(`${API_BASE}${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body || {}),
    });
    if (!res.ok) {
      const detail = await res.json().catch(() => ({}));
      const err = new Error(detail.detail || `Request failed (${res.status})`);
      err.status = res.status;
      throw err;
    }
    return res.json();
  }

  async function apiGet(path) {
    const res = await fetch(`${API_BASE}${path}`);
    if (!res.ok) throw new Error(`Request failed (${res.status})`);
    return res.json();
  }

  function applyTurnResult(result) {
    currentState = result.state;
    renderState();
    renderDocument(result.document_preview);
    renderSuggestions(result.quick_suggestions);
    showWarnings(result.warnings);
    showContradictions(result.contradiction_warnings);

    if (result.active_provider) {
      el.providerSelect.value = result.active_provider;
    }
  }

  // --- Session Lifecycle -----------------------------------------------
  async function startSession() {
    el.chatLog.innerHTML = "";
    el.warningBanner.classList.add("hidden");
    el.contradictionBanner.classList.add("hidden");
    setInputEnabled(false);
    try {
      const result = await apiPost("/session");
      sessionId = result.session_id;
      currentState = result.state;
      renderState();
      renderDocument(result.document_preview);
      renderSuggestions(result.quick_suggestions);
      addMessage("assistant", result.assistant_message);
      if (result.active_provider) el.providerSelect.value = result.active_provider;
    } catch (e) {
      addSystemNote(`Could not initialize session: ${e.message}`);
    } finally {
      setInputEnabled(true);
    }
  }

  function setInputEnabled(enabled) {
    el.chatInput.disabled = !enabled;
    el.sendBtn.disabled = !enabled;
    if (enabled) el.chatInput.focus();
  }

  el.chatForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const message = el.chatInput.value.trim();
    if (!message || !sessionId) return;

    addMessage("user", message);
    el.chatInput.value = "";
    setInputEnabled(false);
    showTyping();

    try {
      const result = await apiPost(`/session/${sessionId}/message`, { session_id: sessionId, message });
      hideTyping();
      addMessage("assistant", result.assistant_message);
      applyTurnResult(result);
    } catch (e) {
      hideTyping();
      if (e.status === 404) {
        addSystemNote("Session expired. Initiating a new interview session…");
        await startSession();
      } else {
        addSystemNote(`Connection error: ${e.message}`);
      }
    } finally {
      setInputEnabled(true);
    }
  });

  el.restartBtn.addEventListener("click", () => {
    if (confirm("Reset current interview and start fresh? All unexported answers will be cleared.")) {
      startSession();
      showToast("Started fresh interview session");
    }
  });

  // --- Quick Persona Selector ------------------------------------------
  el.personaSelect.addEventListener("change", async () => {
    const persona = el.personaSelect.value;
    if (!persona || !sessionId) return;

    try {
      const result = await apiPost(`/session/${sessionId}/load-sample`, { persona });
      applyTurnResult(result);
      addSystemNote(`Loaded demo persona: ${persona === "watson" ? "Dr. John H. Watson" : "Sarah Connor"}`);
      showToast(`Loaded "${persona}" test persona!`);
    } catch (err) {
      showToast(`Failed to load persona: ${err.message}`);
    } finally {
      el.personaSelect.value = "";
    }
  });

  // --- Dynamic Provider Loader ----------------------------------------
  async function loadProviders() {
    try {
      const data = await apiGet("/providers");
      if (!data.providers || !el.providerSelect) return;
      const currentVal = el.providerSelect.value || "mock";
      el.providerSelect.innerHTML = "";
      data.providers.forEach(p => {
        const opt = document.createElement("option");
        opt.value = p.id;
        if (p.id === "mock") {
          opt.textContent = "Engine: Deterministic Mock (Ready - Offline)";
        } else if (p.configured) {
          opt.textContent = `Engine: ${p.name} (Ready)`;
        } else {
          opt.textContent = `Engine: ${p.name} (Key Required)`;
        }
        el.providerSelect.appendChild(opt);
      });
      el.providerSelect.value = currentVal;
    } catch (e) {
      console.warn("Could not load provider list:", e);
    }
  }

  // --- Provider Selector -----------------------------------------------
  el.providerSelect.addEventListener("change", async () => {
    const provider = el.providerSelect.value;
    if (!sessionId) return;
    try {
      const resp = await apiPost(`/session/${sessionId}/provider`, { provider });
      if (resp.status === "unconfigured_fallback") {
        showToast(resp.message, 5000);
        addSystemNote(resp.message);
        el.providerSelect.value = resp.active_provider;
      } else {
        showToast(`Switched active extraction engine to ${provider.toUpperCase()}`);
      }
    } catch (err) {
      showToast(`Error changing engine: ${err.message}`);
    }
  });

  // --- Export Actions --------------------------------------------------
  el.btnPrintDoc.addEventListener("click", () => {
    if (!sessionId) return;
    window.open(`${API_BASE}/session/${sessionId}/export/html`, "_blank");
  });

  el.btnExportMd.addEventListener("click", () => {
    if (!sessionId) return;
    window.location.href = `${API_BASE}/session/${sessionId}/export/markdown`;
    showToast("Downloaded Personal_Wishes_Document.md");
  });

  el.btnExportJson.addEventListener("click", () => {
    if (!sessionId) return;
    window.location.href = `${API_BASE}/session/${sessionId}/export/json`;
    showToast("Downloaded Personal_Wishes_Data.json");
  });

  el.btnCopyDoc.addEventListener("click", async () => {
    if (!sessionId) return;
    try {
      const data = await apiGet(`/session/${sessionId}/document`);
      await navigator.clipboard.writeText(data.document);
      showToast("Document copied to clipboard!");
    } catch (err) {
      showToast("Could not copy document to clipboard");
    }
  });

  // --- Inline Field Correction Modal -----------------------------------
  let activeField = null;

  function openEditModal(field) {
    activeField = field;
    el.modalTitle.textContent = `Edit: ${field.label}`;
    const currentVal = currentState[field.name];

    if (field.type === "bool") {
      el.modalBody.innerHTML = `
        <div class="chip-row">
          <button type="button" class="chip" data-val="true">Yes</button>
          <button type="button" class="chip" data-val="false">No</button>
        </div>
        <div class="modal-hint">Choose Yes or No for this question.</div>
        <div class="modal-error" id="modal-error"></div>`;
      const chips = el.modalBody.querySelectorAll(".chip");
      chips.forEach(chip => {
        if ((chip.dataset.val === "true") === (currentVal === true)) chip.classList.add("selected");
        chip.addEventListener("click", () => {
          chips.forEach(c => c.classList.remove("selected"));
          chip.classList.add("selected");
        });
      });
    } else if (field.type === "list") {
      const listVal = Array.isArray(currentVal) ? currentVal.join(", ") : "";
      el.modalBody.innerHTML = `
        <textarea id="modal-input" placeholder="Comma-separated items, e.g. Alice, Bob">${escapeHtml(listVal)}</textarea>
        <div class="modal-hint">Separate items with commas. Leave blank for none.</div>
        <div class="modal-error" id="modal-error"></div>`;
    } else {
      el.modalBody.innerHTML = `
        <input type="text" id="modal-input" value="${currentVal ? escapeHtml(currentVal) : ""}" />
        <div class="modal-hint">Enter the value, or leave blank to mark as none.</div>
        <div class="modal-error" id="modal-error"></div>`;
    }

    el.modalBackdrop.classList.remove("hidden");
    const input = document.getElementById("modal-input");
    if (input) input.focus();
  }

  function closeEditModal() {
    el.modalBackdrop.classList.add("hidden");
    activeField = null;
  }

  el.modalCancel.addEventListener("click", closeEditModal);
  el.modalCloseX.addEventListener("click", closeEditModal);
  el.modalBackdrop.addEventListener("click", (e) => {
    if (e.target === el.modalBackdrop) closeEditModal();
  });

  el.modalSave.addEventListener("click", async () => {
    if (!activeField || !sessionId) return;
    const errEl = document.getElementById("modal-error");
    let value;

    if (activeField.type === "bool") {
      const selected = el.modalBody.querySelector(".chip.selected");
      if (!selected) { errEl.textContent = "Please select Yes or No."; return; }
      value = selected.dataset.val === "true";
    } else if (activeField.type === "list") {
      const raw = document.getElementById("modal-input").value.trim();
      value = raw ? raw.split(",").map(s => s.trim()).filter(Boolean) : [];
    } else {
      const raw = document.getElementById("modal-input").value.trim();
      value = raw || null;
    }

    try {
      const result = await apiPost(`/session/${sessionId}/correct`, {
        session_id: sessionId, field: activeField.name, value,
      });
      applyTurnResult(result);
      addSystemNote(`Directly corrected "${activeField.label}"`);
      showToast(`Updated "${activeField.label}"`);
      closeEditModal();
    } catch (e) {
      errEl.textContent = e.message || "Failed to update field.";
    }
  });

  // --- Boot Application ------------------------------------------------
  initTheme();
  initSpeechRecognition();
  loadProviders();
  startSession();
})();
